package com.weguard.ui;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import com.aventstack.extentreports.MediaEntityBuilder;
import java.io.IOException;
import java.time.Duration;

public class RolesAndPermissions extends PolicyGroups {

    private void navigateToRolesAndPermissions() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        WebElement RolesAndPermissionsModule = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@href='#/roles']")));
        RolesAndPermissionsModule.click();
        test.info("Successfully navigated to Roles and Permissions module");
    }

    private void createUser(String email, String firstName, String lastName, String isdCode, String mobileNo, String password, String confirmPassword, String role) throws InterruptedException, IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        // Wait for the + icon to create a user
        Thread.sleep(10000);
        WebElement CreateUser = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//mat-icon[text()= 'add']")));
        CreateUser.click();
        test.info("Clicked on the create user button");

        WebElement ValidEmail = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='userName']")));
        ValidEmail.sendKeys(email);

        WebElement SelectRole = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Select Roles']")));
        SelectRole.click();
        Thread.sleep(2000);

        WebElement SelectedRole = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[normalize-space(.)= '" + role + "'])[2]")));
        SelectedRole.click();

        WebElement EnterFirstName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='fName']")));
        EnterFirstName.sendKeys(firstName);

        WebElement EnterLastName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='lName']")));
        EnterLastName.sendKeys(lastName);

        WebElement SelectISDCode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='isdCode']")));
        SelectISDCode.sendKeys(isdCode);
        Thread.sleep(2000);

        WebElement IndiaISDCode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[normalize-space(text())= 'India(+91)']")));
        IndiaISDCode.click();

        WebElement MobileNumber = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='phoneNo']")));
        MobileNumber.sendKeys(mobileNo);

        WebElement EnterPassword = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='password']")));
        EnterPassword.sendKeys(password);

        WebElement ConfirmPassword = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname= 'confirmPassword']")));
        ConfirmPassword.sendKeys(confirmPassword);

        WebElement SIGNUP = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())= 'SIGNUP']")));
        Thread.sleep(3000);

        SIGNUP.click();
        Thread.sleep(3000);

        String screenshotPath = getScreenshot(driver, "Screenshot");
        test.info("Screenshot after clicking on SIGNUP button", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());

        // Verify successful account creation
        try {
            WebElement DownloadButtonAfterSIGNUP = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()= 'download']")));
            if (DownloadButtonAfterSIGNUP.isDisplayed()) {
                test.pass("Account created successfully.");
            } else {
                test.fail("Account creation failed.");
                throw new Exception("User creation failed");
            }
        } catch (Exception e) {
            test.fail("Account creation failed. Exception: " + e.getMessage());
            
            // Capture screenshot if account creation fails
            String failedSignupScreenshotPath = getScreenshot(driver, "SignupFailedScreenshot");
            test.info("Screenshot after signup failure", MediaEntityBuilder.createScreenCaptureFromPath(failedSignupScreenshotPath).build());
            
            // Click the back button to return to the previous page
            Thread.sleep(5000);
            WebElement backButton = driver.findElement(By.cssSelector("i.fas.fa-arrow-circle-left"));
            Thread.sleep(2000);
            backButton.click();
            
            test.info("Clicked on back button to continue with the next test case.");
        }}

    //@Test(priority = 17)
    public void GroupAdminCreationWithValidEmail() throws InterruptedException, IOException {
    	test = extent.createTest("Group admin creation with valid email");
        String GroupAdminEmail = data.getProperty("GroupAdminEmail");
        String GroupAdminFirstName = data.getProperty("GroupAdminFirstName");
        String GroupAdminLastName = data.getProperty("GroupAdminLastName");
        String GroupAdminISDCode = data.getProperty("GroupAdminISDCode");
        String GroupAdminMobileNo = data.getProperty("GroupAdminMobileNumber");
        String GroupAdminPassword = data.getProperty("GroupAdminPassword");
        String GroupAdminConfirmpassword = data.getProperty("GroupAdminConfirmpassword");

        try {
            navigateToRolesAndPermissions();
            createUser(GroupAdminEmail, GroupAdminFirstName, GroupAdminLastName, GroupAdminISDCode, GroupAdminMobileNo, GroupAdminPassword, GroupAdminConfirmpassword, "Group Admin");
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
            test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            throw e;
        }
    }

   // @Test(priority = 18)
    public void GroupAdminCreationWithAlreadyUsedEmail() throws InterruptedException, IOException {
    	test = extent.createTest("Group admin creation with alreadyusedemail");
        String GroupAdminEmail = data.getProperty("GroupAdminEmail");
        String GroupAdminFirstName = data.getProperty("GroupAdminFirstName");
        String GroupAdminLastName = data.getProperty("GroupAdminLastName");
        String GroupAdminISDCode = data.getProperty("GroupAdminISDCode");
        String GroupAdminMobileNo = data.getProperty("GroupAdminMobileNumber");
        String GroupAdminPassword = data.getProperty("GroupAdminPassword");
        String GroupAdminConfirmpassword = data.getProperty("GroupAdminConfirmpassword");

        try {
            Thread.sleep(10000);
            navigateToRolesAndPermissions();
            createUser(GroupAdminEmail, GroupAdminFirstName, GroupAdminLastName, GroupAdminISDCode, GroupAdminMobileNo, GroupAdminPassword, GroupAdminConfirmpassword, "Group Admin");
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
            test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            throw e;
        }
    }

   // @Test(priority = 19)
    public void ObserverCreationWithValidEmail() throws InterruptedException, IOException {
    	test = extent.createTest("Observer creation with valid email");
        String ObserverEmail = data.getProperty("ObserverEmail");
        String ObserverFirstName = data.getProperty("ObserverFirstName");
        String ObserverLastName = data.getProperty("ObserverLastName");
        String ObserverISDCode = data.getProperty("ObserverISDCode");
        String ObserverMobileNo = data.getProperty("ObserverMobileNumber");
        String ObserverPassword = data.getProperty("ObserverPassword");
        String ObserverConfirmpassword = data.getProperty("ObserverConfirmpassword");

        try {
            navigateToRolesAndPermissions();
            createUser(ObserverEmail, ObserverFirstName, ObserverLastName, ObserverISDCode, ObserverMobileNo, ObserverPassword, ObserverConfirmpassword, "Observer");
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
            test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            throw e;
        }
    }

   // @Test(priority = 20)
    public void ObserverCreationWithSameEmail() throws InterruptedException, IOException {
    	test = extent.createTest("Observer creation with alreadyusedemail");
        String ObserverEmail = data.getProperty("ObserverEmail");
        String ObserverFirstName = data.getProperty("ObserverFirstName");
        String ObserverLastName = data.getProperty("ObserverLastName");
        String ObserverISDCode = data.getProperty("ObserverISDCode");
        String ObserverMobileNo = data.getProperty("ObserverMobileNumber");
        String ObserverPassword = data.getProperty("ObserverPassword");
        String ObserverConfirmpassword = data.getProperty("ObserverConfirmpassword");

        try {
            navigateToRolesAndPermissions();
            createUser(ObserverEmail, ObserverFirstName, ObserverLastName, ObserverISDCode, ObserverMobileNo, ObserverPassword, ObserverConfirmpassword, "Observer");
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
            test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            throw e;
        }
    }
    @Test(priority = 21)
    public void GroupAdminToAccountAdmin() throws InterruptedException, IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String GroupAdminEmailID = data.getProperty("GAEmail");
        test = extent.createTest("Role Update from Group Admin To Account Admin ");

        try {
            // Navigate to the Roles and Permissions module
            WebElement RolesAndPermissionsModule = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@href='#/roles']")));
            RolesAndPermissionsModule.click();

            // Search for the user by email ID or role
            WebElement Search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@data-placeholder='Filter by emailId or role']")));
            Thread.sleep(5000);
            Search.clear();
            Search.sendKeys(GroupAdminEmailID);
           
       Thread.sleep(3000);
            // Click the Edit icon for the user
            WebElement EditIcon = driver.findElement(By.xpath("//*[text()='edit']"));
            
            EditIcon.click();

            // Change the user's role
            WebElement DropdownForRoleChange = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Group Admin']")));
            DropdownForRoleChange.click();
            
            WebElement RoleSelection = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[normalize-space(.)='Account Admin'])[2]")));
            RoleSelection.click();

            // Save the changes
            WebElement Save = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())='SAVE']")));
            Save.click();

            // Log success in the Extent Report
            test.pass("Role updated successfully from Group admin to Account admin.");

        } catch (Exception e) {
            // Log the exception in the Extent Report
        	 String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
             test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
             Thread.sleep(5000);
             WebElement backButton = driver.findElement(By.cssSelector("i.fas.fa-arrow-circle-left"));
             Thread.sleep(2000);
             backButton.click();
             
             test.info("Clicked on back button to continue with the next test case.");
             
             throw e;
        }
    }
   @Test(priority = 22)
    public void GroupAdminToObserver() throws InterruptedException, IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String GroupAdminEmailID = data.getProperty("GAEmail1");
        test = extent.createTest("Role Update from Group Admin To Observer ");

        try {
           

            // Search for the user by email ID or role
            WebElement Search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@data-placeholder='Filter by emailId or role']")));
            Thread.sleep(3000);
            Search.clear();
            Search.sendKeys(GroupAdminEmailID);
             Thread.sleep(5000);
             Search.click();
             
            // Click the Edit icon for the user
            WebElement EditIcon = driver.findElement(By.xpath("//*[text()='edit']"));
            
            EditIcon.click();

            // Change the user's role
            WebElement DropdownForRoleChange = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Group Admin']")));
            DropdownForRoleChange.click();
            
            WebElement RoleSelection = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[normalize-space(.)='Observer'])[2]")));
            RoleSelection.click();

            // Save the changes
            WebElement Save = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())='SAVE']")));
            Save.click();

            // Log success in the Extent Report
            test.pass("Role updated successfully from Group admin to Observer.");

        } catch (Exception e) {
            // Log the exception in the Extent Report
        	 String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
             test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
             Thread.sleep(5000);
             WebElement backButton = driver.findElement(By.cssSelector("i.fas.fa-arrow-circle-left"));
             Thread.sleep(2000);
             backButton.click();
             
             test.info("Clicked on back button to continue with the next test case.");
             throw e;
        }
    }
   @Test(priority = 23)
    public void ObserverToAccountAdmin() throws InterruptedException, IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String ObserverEmailID = data.getProperty("ObEmail");
        test = extent.createTest("Role Update from Observer to Account Admin ");

        try {
           

            // Search for the user by email ID or role
            WebElement Search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@data-placeholder='Filter by emailId or role']")));
            Thread.sleep(3000);
            Search.clear();
            Search.sendKeys(ObserverEmailID);
             Thread.sleep(5000);
             Search.click();
            
            // Click the Edit icon for the user
            WebElement EditIcon = driver.findElement(By.xpath("//*[text()='edit']"));
            
            EditIcon.click();

            // Change the user's role
            WebElement DropdownForRoleChange = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Observer']")));
            DropdownForRoleChange.click();
            
            WebElement RoleSelection = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[normalize-space(.)='Account Admin'])[2]")));
            RoleSelection.click();

            // Save the changes
            WebElement Save = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())='SAVE']")));
            Save.click();

            // Log success in the Extent Report
            test.pass("Role updated successfully from Observer to Account admin.");

        } catch (Exception e) {
            // Log the exception in the Extent Report
        	 String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
             test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
             Thread.sleep(5000);
             WebElement backButton = driver.findElement(By.cssSelector("i.fas.fa-arrow-circle-left"));
             Thread.sleep(2000);
             backButton.click();
             
             test.info("Clicked on back button to continue with the next test case.");
             throw e;
        }
    }
    @Test(priority = 24)
    public void ObserverToGroupAdmin() throws InterruptedException, IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String ObserverEmailID = data.getProperty("ObEmail1");
        test = extent.createTest("Role Update from Observer to Group Admin.");

        try {
           

            // Search for the user by email ID or role
            WebElement Search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@data-placeholder='Filter by emailId or role']")));
           
            Thread.sleep(3000);
            Search.clear();
            Search.sendKeys(ObserverEmailID);
             Thread.sleep(5000);
             Search.click();
            
            // Click the Edit icon for the user
            WebElement EditIcon = driver.findElement(By.xpath("//*[text()='edit']"));
            
            EditIcon.click();

            // Change the user's role
            WebElement DropdownForRoleChange = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Observer']")));
            DropdownForRoleChange.click();
            
            WebElement RoleSelection = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[normalize-space(.)='Group Admin'])[2]")));
            RoleSelection.click();

            // Save the changes
            WebElement Save = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())='SAVE']")));
            Save.click();

            // Log success in the Extent Report
            test.pass("Role updated successfully from Observer to Group admin.");

        } catch (Exception e) {
            // Log the exception in the Extent Report
        	 String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
             test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
             Thread.sleep(5000);
             WebElement backButton = driver.findElement(By.cssSelector("i.fas.fa-arrow-circle-left"));
             Thread.sleep(2000);
             backButton.click();
             
             test.info("Clicked on back button to continue with the next test case.");
             throw e;
        }
    }
    @Test(priority = 25)
    public void AccountAdminToGroupAdmin() throws InterruptedException, IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String AccountAdminEmailID = data.getProperty("AccAdminEmail");
        test = extent.createTest("Role Update from Account admin to Group Admin.");

        try {
           

            // Search for the user by email ID or role
            WebElement Search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@data-placeholder='Filter by emailId or role']")));
           
            Thread.sleep(3000);
            Search.clear();
            Search.sendKeys(AccountAdminEmailID);
             Thread.sleep(5000);
             Search.click();
            
            // Click the Edit icon for the user
            WebElement EditIcon = driver.findElement(By.xpath("//*[text()='edit']"));
            
            EditIcon.click();

            // Change the user's role
            WebElement DropdownForRoleChange = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Account Admin']")));
            DropdownForRoleChange.click();
            
            WebElement RoleSelection = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[normalize-space(.)='Group Admin'])[2]")));
            RoleSelection.click();

            // Save the changes
            WebElement Save = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())='SAVE']")));
            Save.click();

            // Log success in the Extent Report
            test.pass("Role updated successfully from Account Admin to Group admin.");

        } catch (Exception e) {
            // Log the exception in the Extent Report
        	 String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
             test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
             Thread.sleep(5000);
             WebElement backButton = driver.findElement(By.cssSelector("i.fas.fa-arrow-circle-left"));
             Thread.sleep(2000);
             backButton.click();
             
             test.info("Clicked on back button to continue with the next test case.");
             throw e;
        }
    }
    @Test(priority = 26)
    public void AccountAdminToObserver() throws InterruptedException, IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String AccountAdminEmailID = data.getProperty("AccAdminEmail1");
        test = extent.createTest("Role Update from Account admin to Observer.");

        try {
           

            // Search for the user by email ID or role
            WebElement Search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@data-placeholder='Filter by emailId or role']")));
           
            Thread.sleep(3000);
            Search.clear();
            Search.sendKeys(AccountAdminEmailID);
             Thread.sleep(5000);
             Search.click();
            
            // Click the Edit icon for the user
            WebElement EditIcon = driver.findElement(By.xpath("//*[text()='edit']"));
            
            EditIcon.click();

            // Change the user's role
            WebElement DropdownForRoleChange = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Account Admin']")));
            DropdownForRoleChange.click();
            
            WebElement RoleSelection = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[normalize-space(.)='Observer'])[2]")));
            RoleSelection.click();

            // Save the changes
            WebElement Save = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())='SAVE']")));
            Save.click();

            // Log success in the Extent Report
            test.pass("Role updated successfully from Account Admin to Observer.");

        } catch (Exception e) {
            // Log the exception in the Extent Report
        	 String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
             test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
             Thread.sleep(5000);
             WebElement backButton = driver.findElement(By.cssSelector("i.fas.fa-arrow-circle-left"));
             Thread.sleep(2000);
             backButton.click();
             
             test.info("Clicked on back button to continue with the next test case.");
             throw e;
        }
    }
    @Test(priority = 27)
    public void DeleteUser() throws InterruptedException, IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String DeleteUser = data.getProperty("DeleteUser");
        test = extent.createTest("Delete a user from roles and permissions");

        try {
           

            // Search for the user by email ID or role
            WebElement Search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@data-placeholder='Filter by emailId or role']")));
           
            Thread.sleep(3000);
            Search.clear();
            Search.sendKeys(DeleteUser);
             Thread.sleep(5000);
             Search.click();
            
            // Click the Edit icon for the user
            WebElement EditIcon = driver.findElement(By.xpath("//*[text()='edit']"));
            
            EditIcon.click();

            // Change the user's role
            WebElement DropdownForRoleChange = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Account Admin']")));
            DropdownForRoleChange.click();
            
            WebElement RoleSelection = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[normalize-space(.)='Observer'])[2]")));
            RoleSelection.click();

            // Save the changes
            WebElement Save = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())='SAVE']")));
            Save.click();

            // Log success in the Extent Report
            test.pass("Role updated successfully from Account Admin to Observer.");

        } catch (Exception e) {
            // Log the exception in the Extent Report
        	 String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
             test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
             Thread.sleep(5000);
             WebElement backButton = driver.findElement(By.cssSelector("i.fas.fa-arrow-circle-left"));
             Thread.sleep(2000);
             backButton.click();
             
             test.info("Clicked on back button to continue with the next test case.");
             throw e;
        }
    }
}
