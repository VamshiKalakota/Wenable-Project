package com.weguard.ui;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class DashBoard extends LoginFactor {

	@Test(priority = 7)
	public void dashboardData() throws InterruptedException {
		test = extent.createTest("DashboardData");

		Thread.sleep(5000);

		// Retrieve and print dash board data
		WebElement activeUsers = driver.findElement(By.xpath("(//div[@class='count'])[1]"));
		String activeUsersCount = activeUsers.getText();
		test.info("Active Users Count: " + activeUsersCount);

		WebElement activeDevices = driver.findElement(By.xpath("(//div[@class='count'])[2]"));
		String activeDevicesCount = activeDevices.getText();
		test.info("Active Devices Count: " + activeDevicesCount);

		WebElement deviceCheckins = driver.findElement(By.xpath("(//div[@class='count'])[3]"));
		String deviceCheckinsCount = deviceCheckins.getText();
		test.info("Device Checkins Count: " + deviceCheckinsCount);

		WebElement weBoxFiles = driver.findElement(By.xpath("(//div[@class='count'])[4]"));
		String weBoxFilesCount = weBoxFiles.getText();
		test.info("WeBox Files Count: " + weBoxFilesCount);

		WebElement weTalkMessages = driver.findElement(By.xpath("(//div[@class='count'])[5]"));
		String weTalkMessagesCount = weTalkMessages.getText();
		test.info("WeTalk Messages Count: " + weTalkMessagesCount);

		WebElement weTalkCalls = driver.findElement(By.xpath("(//div[@class='count'])[6]"));
		String weTalkCallsCount = weTalkCalls.getText();
		test.info("WeTalk Calls Count: " + weTalkCallsCount);
	}

	@Test(priority = 8)
	public void RecentlyEnrolledDevices() throws InterruptedException {
		test = extent.createTest("Recently Enrolled Devices Data");

		Thread.sleep(2000);

		// Retrieve and print dash board data
		WebElement tableElement = driver.findElement(By.xpath("(//mat-table[@role='table'])[1]"));

		// Get all rows of the table
		List<WebElement> rows = tableElement.findElements(By.xpath(".//mat-row"));

		// Create HTML table
		StringBuilder htmlTable = new StringBuilder();
		htmlTable.append("<table border='1' style='border-collapse: collapse; width: 100%;'>")
				.append("<tr><th>Device ID</th><th>Maker</th><th>Time</th></tr>");

		// Iterate through each row and extract cell data
		for (WebElement row : rows) {
			List<WebElement> cells = row.findElements(By.xpath(".//mat-cell"));
			if (cells.size() >= 3) {
				htmlTable.append("<tr>").append("<td>").append(cells.get(0).getText().trim()).append("</td>")
						.append("<td>").append(cells.get(1).getText().trim()).append("</td>").append("<td>")
						.append(cells.get(2).getText().trim()).append("</td>").append("</tr>");
			}
		}

		htmlTable.append("</table>");

		// Log the HTML table to the extent report
		test.info("Recently Enrolled Devices:<br>" + htmlTable.toString());
	}

	@Test(priority = 9)
	public void Highdataconsumingdevices() throws InterruptedException {
		test = extent.createTest("Devices Consuming High Data");

		Thread.sleep(2000);

		// Retrieve and print dash board data
		WebElement tableElement = driver.findElement(By.xpath("(//mat-table[@role='table'])[2]"));

		// Get all rows of the table
		List<WebElement> rows = tableElement.findElements(By.xpath(".//mat-row"));

		// Create HTML table
		StringBuilder htmlTable = new StringBuilder();
		htmlTable.append("<table border='1' style='border-collapse: collapse; width: 100%;'>")
				.append("<tr><th>Maker</th><th>Device ID</th><th>Consumed Data</th><th>Provider</th></tr>");

		// Iterate through each row and extract cell data
		for (WebElement row : rows) {
			List<WebElement> cells = row.findElements(By.xpath(".//mat-cell"));
			if (cells.size() >= 4) {
				htmlTable.append("<tr>").append("<td>").append(cells.get(0).getText().trim()).append("</td>")
						.append("<td>").append(cells.get(1).getText().trim()).append("</td>").append("<td>")
						.append(cells.get(2).getText().trim()).append("</td>").append("<td>")
						.append(cells.get(3).getText().trim()).append("</td>").append("</tr>");
			}
		}

		htmlTable.append("</table>");

		// Log the HTML table to the extent report
		test.info("Devices Consuming High Data:<br>" + htmlTable.toString());
	}
	@Test(priority = 10)
	public void TopFiveAppUsage() throws InterruptedException {
		test = extent.createTest("Top five app usage");

		Thread.sleep(2000);

		// Retrieve and print dash board data
		WebElement tableElement = driver.findElement(By.xpath("(//mat-table[@role='table'])[4]"));

		// Get all rows of the table
		List<WebElement> rows = tableElement.findElements(By.xpath(".//mat-row"));

		// Create HTML table
		StringBuilder htmlTable = new StringBuilder();
		htmlTable.append("<table border='1' style='border-collapse: collapse; width: 100%;'>")
				.append("<tr><th>App Name</th><th>Screen Time</th></tr>");

		// Iterate through each row and extract cell data
		for (WebElement row : rows) {
			List<WebElement> cells = row.findElements(By.xpath(".//mat-cell"));
			if (cells.size() >= 2) {
				htmlTable.append("<tr>").append("<td>").append(cells.get(0).getText().trim()).append("</td>")
						.append("<td>").append(cells.get(1).getText().trim()).append("</td>").append("</tr>");
			}
		}

		htmlTable.append("</table>");

		// Log the HTML table to the extent report
		test.info("Top five app usage :<br>" + htmlTable.toString());
	}
	@Test(priority = 11)
	public void TopFiveDeviceScreenTime() throws InterruptedException {
		test = extent.createTest("Top five device screen time");

		Thread.sleep(2000);

		// Retrieve and print dash board data
		WebElement tableElement = driver.findElement(By.xpath("(//mat-table[@role='table'])[3]"));

		// Get all rows of the table
		List<WebElement> rows = tableElement.findElements(By.xpath(".//mat-row"));

		// Create HTML table
		StringBuilder htmlTable = new StringBuilder();
		htmlTable.append("<table border='1' style='border-collapse: collapse; width: 100%;'>")
				.append("<tr><th>Device ID</th><th>Total Screen Time</th></tr>");

		// Iterate through each row and extract cell data
		for (WebElement row : rows) {
			List<WebElement> cells = row.findElements(By.xpath(".//mat-cell"));
			if (cells.size() >= 2) {
				htmlTable.append("<tr>").append("<td>").append(cells.get(0).getText().trim()).append("</td>")
						.append("<td>").append(cells.get(1).getText().trim()).append("</td>").append("</tr>");
			}
		}

		htmlTable.append("</table>");

		// Log the HTML table to the extent report
		test.info("Top five device screen time :<br>" + htmlTable.toString());
	}
	@Test(priority = 12)
	public void RecentActivity() throws InterruptedException {
		test = extent.createTest("Recent Activity");

		Thread.sleep(3000);

		// Retrieve and print dash board data
		WebElement tableElement = driver.findElement(By.xpath("//div[@class='activity-alert overflow-auto tble-add']"));

		// Get all rows of the table
		List<WebElement> rows = tableElement.findElements(By.xpath(".//mat-row"));

		// Create HTML table
		StringBuilder htmlTable = new StringBuilder();
		htmlTable.append("<table border='1' style='border-collapse: collapse; width: 100%;'>")
				.append("<tr><th>Log</th><th>Date&Time</th></tr>");

		// Iterate through each row and extract cell data
		for (WebElement row : rows) {
			List<WebElement> cells = row.findElements(By.xpath(".//mat-cell"));
			if (cells.size() >= 2) {
				htmlTable.append("<tr>").append("<td>").append(cells.get(0).getText().trim()).append("</td>")
						.append("<td>").append(cells.get(1).getText().trim()).append("</td>").append("</tr>");
			}
		}

		htmlTable.append("</table>");

		// Log the HTML table to the extent report
		test.info("Recent Activity :<br>" + htmlTable.toString());
	}


}
