package com.weguard.ui;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;

public class Devices extends DashBoard {

	//@Test(priority = 13)
    public void DownloadDeviceInfo() throws IOException {
        test = ExtentReportManager.createTest("DownloadDeviceInfo");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        String downloadPath = System.getProperty("user.home") + "/Downloads/"; // Path to the download directory
        

        try {
            // Navigate to Devices module
            WebElement devicesModule = wait.until(
                ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='#/devices']"))
            );
            devicesModule.click();
            test.info("Successfully navigated to Devices module");

            // Open the menu and click on Download Device Info
            WebElement menu = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[text()='menu'])[2]")));
            menu.click();
            WebElement downloadDeviceInfo = wait.until(
                ExpectedConditions.elementToBeClickable(By.xpath("(//*[@role= 'menuitem'])[1]"))
            );
            downloadDeviceInfo.click();
            WebElement downloadButton = wait.until(
                ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='DOWNLOAD']"))
            );
            downloadButton.click();
            test.info("Clicked on Download button");

            // Wait for the file to be downloaded
            File downloadDir = new File(downloadPath);
            File[] filesBefore = downloadDir.listFiles();
            boolean fileDownloaded = false;
            long startTime = System.currentTimeMillis();

            while (System.currentTimeMillis() - startTime < 60000) { // Wait up to 60 seconds
                File[] filesAfter = downloadDir.listFiles();
                if (filesAfter.length > filesBefore.length) { // New file is downloaded
                    fileDownloaded = true;
                    break;
                }
                try {
                    Thread.sleep(1000); // Sleep for a short time before checking again
                } catch (InterruptedException e) {
                    test.fail("Interrupted while waiting for file download");
                }
            }

            // Verify the file is downloaded
            if (fileDownloaded) {
                // Attach the file to the Extent report
                File downloadedFile = downloadDir.listFiles()[downloadDir.listFiles().length - 1];
                String filePath = downloadedFile.getAbsolutePath();
                test.info("Device info CSV downloaded", MediaEntityBuilder.createScreenCaptureFromPath(filePath).build());
            } else {
                test.fail("Device info CSV was not downloaded.");
                String screenshotPath = getScreenshot(driver, "DownloadDeviceInfoFailure");
                test.fail("File download failed.", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            }
        } catch (NoSuchElementException e) {
            String screenshotPath = getScreenshot(driver, "DownloadDeviceInfoNoSuchElementException");
            test.fail("An element was not found: " + e.getMessage(), 
                      MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "DownloadDeviceInfoException");
            test.fail("An error occurred: " + e.getMessage(), 
                      MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        }
    
	}

  //@Test(priority = 14)
	public void DevicesModule() throws InterruptedException {
		test = extent.createTest("Devices");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		String DeviceID = data.getProperty("deviceID");

		// Wait for the search input field to be visible and then send keys
		WebElement Search = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='text']")));
		Search.clear(); // Clear the input field before sending keys
		Search.sendKeys(DeviceID);
		test.info("Entered Device ID into search field");

		// Introduce a brief wait to ensure the search results have time to update
		Thread.sleep(5000);

		// Find and click on the 'create' button with retry logic
		WebElement ClickOnDeviceID = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='create']")));
		ClickOnDeviceID.click();
		test.info("Clicked on edit device ID");
		try {
			// Wait for the device details view to be visible
			WebElement deviceDetailsView = wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//*[@class='mat-tooltip-trigger dot active active-status-icon']")));

			// Verify whether the device status is online or offline.
			if (deviceDetailsView.isDisplayed()) {
				test.pass("Device is online");
			} else {
				test.fail("Device is offline. Click on refresh to update.");
			}

		} catch (Exception e) {
			// Capture any exception and log it in the report
			test.fail("Device is offline. Click on refresh to update.");
			e.printStackTrace();
		}
	}

	//@Test(priority = 15)
	public void DeviceCommands() throws InterruptedException {
		test = extent.createTest("Device Commands");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

		WebElement KioskLockUnLockcommand = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("(//div[contains(@class,'commandDiv displayColFlex')]//button)[2]")));
		KioskLockUnLockcommand.click();
		test.info("Successfully triggred Kiosk Lock/UnLock command");
		/*
		 * WebElement AdminLockcommand =
		 * wait.until(ExpectedConditions.elementToBeClickable(By.
		 * xpath("(//div[contains(@class,'commandDiv displayColFlex')]//button)[3]")));
		 * AdminLockcommand.click();
		 * test.info("Successfully triggred Admin Lock command"); WebElement
		 * ClearKioskPasscodecommand =
		 * wait.until(ExpectedConditions.elementToBeClickable(By.
		 * xpath("(//div[contains(@class,'commandDiv displayColFlex')]//button)[4]")));
		 * ClearKioskPasscodecommand.click();
		 * test.info("Successfully triggred Clear Kiosk Passcode command");
		 */
		WebElement Rebootcommand = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("(//div[contains(@class,'commandDiv displayColFlex')]//button)[1]")));
		Rebootcommand.click();
		WebElement RebootcommandAccept = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='YES']")));
		RebootcommandAccept.click();
		test.info("Successfully triggred Reboot command");

	}

}
