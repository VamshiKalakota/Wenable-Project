package com.weguard.ui;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class PolicyGroups extends Devices {

	//@Test(priority = 16)
	public void Policies() {
	    test = extent.createTest("Policies");
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	    String policyName = data.getProperty("Policy");

	    try {
	        // Find and click on Policy Groups module
	        WebElement devicesModule = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@href='#/groups']")));
	        devicesModule.click();
	        test.info("Successfully navigated to Policy Groups module");

	        // Wait for the search input field to be visible and then send keys
	        WebElement searchField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='float-input']")));
	        searchField.clear();
	        searchField.sendKeys(policyName);
	        test.info("Entered the policy name into search field");
              Thread.sleep(5000); 
	        // Wait for the search results to update
	        WebElement policyGroup = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//mat-cell[@role='cell']//section)[1]")));
	        policyGroup.click();
	        test.info("Clicked on the searched policy group");

	        // Retrieve and store the initial policy version
	        WebElement versionElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(normalize-space(.), 'Version:')])[1]")));
	        String initialVersionText = versionElement.getText();
	        System.out.println("Raw version text: " + initialVersionText);
	        int initialVersion = Integer.parseInt(extractVersionNumber(initialVersionText));
	        test.info("Initial policy version: " + initialVersion);

	        // Wait for the policy dialog and click Save and Continue
	        WebElement saveAndContinueButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[contains(@class,'mat-focus-indicator mat-raised-button')])[1]")));
	        if (saveAndContinueButton.isDisplayed()) {
	            Thread.sleep(5000); // Ensure that the dialog and actions are complete
	            saveAndContinueButton.click();
	            test.info("Clicked on Save and Continue button");
	        } else {
	            test.fail("Save and Continue button not found or not visible");
	            return; // Exit the test as further steps depend on this action
	        }

	        // Click the Update Policy button
	        WebElement updatePolicyButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(@class,'mat-focus-indicator btn-clr')])[2]")));
	        updatePolicyButton.click();
	        test.info("Clicked on Update Policy button");

	        // Wait for the updated version to be visible and check for the increased version
	        // Introduce a short wait to ensure the page is fully updated
	        Thread.sleep(5000);

	        // Re-fetch the version element after update
	        versionElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(normalize-space(.), 'Version:')])[1]")));
	        String updatedVersionText = versionElement.getText();
	        System.out.println("Raw updated version text: " + updatedVersionText);
	        int updatedVersion = Integer.parseInt(extractVersionNumber(updatedVersionText));
	        test.info("Updated policy version: " + updatedVersion);

	        // Check if the version number has increased by 1
	        if (updatedVersion == initialVersion + 1) {
	            test.pass("Policy version updated successfully to " + updatedVersion);
	        } else {
	            test.fail("Version did not increase as expected. Current version: " + updatedVersion);
	        }

	    } catch (Exception e) {
	        test.fail("An error occurred during the test: " + e.getMessage());
	        e.printStackTrace();
	    }
	}

	private String extractVersionNumber(String versionText) {
	    // Extract the version number assuming it follows the text 'Version:'
	    String version = versionText.replaceAll(".*Version:", "").trim();
	    version = version.replaceAll("\\D+", ""); // Remove non-numeric characters
	    return version;
	}}