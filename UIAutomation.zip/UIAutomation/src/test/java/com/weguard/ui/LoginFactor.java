package com.weguard.ui;

import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;

class LoginFactor extends Base {

	//@Test(priority = 1)
    public void WeGuardSupportChaticon() throws IOException {
        test = ExtentReportManager.createTest("Test WeGuard Support Chat icon");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        String baseURL = data.getProperty("BaseURL");
        driver.get(baseURL);

        try {
            WebElement supportIcon = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='zsiq_user siqicon siqico-chat']"))
            );

            if (supportIcon.isDisplayed()) {
                test.pass("The WeGuard Support icon is displayed correctly.");
            } else {
                test.fail("The WeGuard Support icon is not displayed.");
            }
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "WeGuardSupportChaticonFailure");
            test.fail("An error occurred: " + e.getMessage(), 
                      MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        }
    }

   // @Test(priority = 2)
    public void WeGuardLoginpagelogo() throws IOException {
        test = ExtentReportManager.createTest("Test WeGuard Login page logo");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        String baseURL = data.getProperty("BaseURL");
        driver.get(baseURL);

        try {
            WebElement logoElement = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@src='assets/weguard_login_1024w.png']"))
            );

            if (logoElement.isDisplayed()) {
                test.pass("The logo is displayed correctly.");
            } else {
                test.fail("The logo is not displayed.");
            }
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "WeGuardLoginpagelogoFailure");
            test.fail("An error occurred: " + e.getMessage(), 
                      MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        }
    }

    //@Test(priority = 3)
    public void WeGuardTitle() throws IOException {
        test = ExtentReportManager.createTest("Test WeGuard Title");
        String baseURL = data.getProperty("BaseURL");
        String expectedTitle = data.getProperty("AccountTitle");
        driver.get(baseURL);

        try {
            String actualTitle = driver.getTitle();
            Assert.assertEquals(actualTitle, expectedTitle, "Title does not match");
            test.pass("Title is being displayed correctly: " + actualTitle);
        } catch (AssertionError e) {
            String screenshotPath = getScreenshot(driver, "WeGuardTitleFailure");
            test.fail("Failed to get the Title: " + e.getMessage(), 
                      MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "WeGuardTitleException");
            test.fail("An error occurred: " + e.getMessage(), 
                      MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        }
    }

   // @Test(priority = 4)
    public void testLoginWithEmptyCredentials() throws IOException {
        test = ExtentReportManager.createTest("Test Login With Empty Credentials");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        String baseURL = data.getProperty("BaseURL");
        driver.get(baseURL);

        try {
            WebElement signInButton = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text() = 'Sign in']"))
            );
            signInButton.click();

            test.fail("Sign in should not be successful with empty credentials.");
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "LoginWithEmptyCredentialsFailure");
            test.fail("An error occurred: " + e.getMessage(), 
                      MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        }
    }

    //@Test(priority = 5)
    public void testLoginWithInvalidCredentials() throws IOException {
        test = ExtentReportManager.createTest("Test Login With Invalid Credentials");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        String baseURL = data.getProperty("BaseURL");
        String invalidUserName = data.getProperty("invalidUsername");
        String invalidPassword = data.getProperty("invalidPassword");
        driver.get(baseURL);

        try {
            WebElement emailInput = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Email']"))
            );
            emailInput.sendKeys(invalidUserName);

            WebElement passwordInput = driver.findElement(By.xpath("//input[@placeholder='Password']"));
            passwordInput.sendKeys(invalidPassword);

            WebElement signInButton = driver.findElement(By.xpath("//*[text() = 'Sign in']"));
            signInButton.click();

            test.fail("Login with invalid credentials should not be successful.");
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "LoginWithInvalidCredentialsFailure");
            test.fail("An error occurred: " + e.getMessage(), 
                      MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        }
    }

	@Test(priority = 6)
    public void testLoginWithValidCredentials() throws InterruptedException, IOException {
        // Create a test in ExtentReports
        test = ExtentReportManager.createTest("testLoginWithValidCredentials");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String baseURL = data.getProperty("BaseURL");
        driver.get(baseURL);

        // Enter valid user name and password
        String username = data.getProperty("username");
        String password = data.getProperty("password");
        Thread.sleep(3000);
        
        WebElement emailInput = wait
                .until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Email']")));
        emailInput.sendKeys(username);

        // Wait for the password input field to be visible and interactable
        WebElement passwordInput = wait
                .until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Password']")));
        passwordInput.sendKeys(password);

        // Wait for the sign-in button to be clickable
        WebElement signInButton = wait
                .until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text() = 'Sign in']")));
        signInButton.click();
        WebElement DashboardModule = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@href='#/dashboard']")));
        // Check if navigation to Dashboard page was successful
        try {

        	if(DashboardModule.isDisplayed()) {
                test.pass("Successfully Logged In.");
                test.info("Successfully navigated to Dashboard module");
            } else {
                test.info("Page is loading");
                String screenshotPath = getScreenshot(driver, "dashboardisnotnavigatedFailedScreenshot");
                test.fail("Failed to Login", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
               
            }
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
            test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            throw e; // rethrow the exception after logging
        }
    }
}
