package com.weguard.ui;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentReportManager extends TestListenerAdapter {
	private static ExtentSparkReporter spark;
	private static ExtentReports extent;
	private static ExtentTest logger;
	public WebDriver driver;

	public static void initialize() {
		// Time stamp for unique report name
		String timestamp = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date());
		String reportName = "UI_Test_Report_" + timestamp + ".html";

		// Initialize ExtentReports and attach ExtentSparkReporter
		spark = new ExtentSparkReporter(reportName);
		extent = new ExtentReports();
		extent.attachReporter(spark);
	}

	public static ExtentTest createTest(String testName) {
		// Create a new test in the report
		return extent.createTest(testName);
	}

	public static ExtentReports getExtentReports() {
		return extent;
	}

	public static void flushReport() {
		// Flush and close the report
		extent.flush();
	}
	
	public void onTestFailure(ITestResult trw) {
		logger = extent.createTest(trw.getName()); // create a new entry in the report
		logger.log(Status.FAIL, MarkupHelper.createLabel(trw.getName(), ExtentColor.RED)); // Send the failed
																							// information
		String screenshotPath = System.getProperty("user.dir") + "\\Screenshots\\" + trw.getName() + ".png";
		File f = new File(screenshotPath);
		if (f.exists()) {
			try {
				logger.fail("Screenshot is below:" + logger.addScreenCaptureFromPath(screenshotPath));
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			try {
				TakesScreenshot screenshot = (TakesScreenshot) driver;
				File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(srcFile, new File(screenshotPath));
				logger.fail("Screenshot is below:" + logger.addScreenCaptureFromPath(screenshotPath));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onTestSuccess(ITestResult tr) {
		// Create a test in the report for successful test cases
		logger = createTest(tr.getName());
		logger.log(Status.PASS, MarkupHelper.createLabel(tr.getName(), ExtentColor.GREEN));
	}
}
