package com.weguard.ui;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class WeBoxFiles extends PolicyGroups {

	//@Test(priority = 16)
    public void WeBoxModule() throws InterruptedException {
        test = extent.createTest("WeBox Module");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        
        // Path to the file on macOS
        String filePath = data.getProperty("filepath");// Update this path to the actual file path

        // Find and click on WeBox module
        WebElement weBoxModule = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@href='#/webox']")));
        weBoxModule.click();
        test.info("Successfully navigated to WeBox module");
        Thread.sleep(5000);

        // Click on the upload icon
        WebElement uploadIcon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(text(), 'cloud_upload')]")));
        uploadIcon.click();
        test.info("Clicked on the file/folder upload icon.");

        // Click on "Upload file" button
        WebElement uploadForFileSelection = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='p-element upload-btn p-button p-component ng-star-inserted']")));
        uploadForFileSelection.click();
        test.info("Clicked on upload file button to select a file.");

    
        Thread.sleep(15000);
        // Click on the "UPLOAD" button to finalize the upload
        WebElement uploadFile = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("")));
        uploadFile.click();
        test.info("File uploaded successfully.");
    }
}