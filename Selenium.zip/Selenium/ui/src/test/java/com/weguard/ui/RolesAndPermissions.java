package com.weguard.ui;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;

import java.io.IOException;
import java.time.Duration;

public class RolesAndPermissions extends PolicyGroups {

	@Test(priority = 17)
	public void Roles() throws InterruptedException, IOException {
	    test = extent.createTest("Roles and Permissions");
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	    String Email = data.getProperty("Email");
	    String FirstName = data.getProperty("FirstName");
	    String LastName = data.getProperty("LastName");
	    String ISDCode = data.getProperty("ISDCode");
	    String MobileNo = data.getProperty("MobileNumber");
	    String Password = data.getProperty("Password");
	    String Confirmpassword = data.getProperty("Confirmpassword");
	    
	    try {
	        // Find and click on Roles and Permissions module
	        WebElement RolesAndPermissionsModule = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@href='#/roles']")));
	        RolesAndPermissionsModule.click();
	        test.info("Successfully navigated to Roles and Permissions module");

	        // Wait for the + icon to create a user
	        WebElement CreateUser = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//mat-icon[text()= 'add']")));
	        CreateUser.click();
	        test.info("Clicked on the create user button");

	        WebElement ValidEmail = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='userName']")));
	        ValidEmail.sendKeys(Email); 
	        WebElement SelectRole = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Select Roles']")));
	        SelectRole.click();
	        Thread.sleep(4000);
	        WebElement GroupAdminRole = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[normalize-space(.)= 'Group Admin'])[2]")));
	        GroupAdminRole.click();

	        WebElement EnterfirstName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='fName']")));
	        EnterfirstName.sendKeys(FirstName);
	        WebElement EnterLastName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='lName']")));
	        EnterLastName.sendKeys(LastName);
	        WebElement SelectISDCode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='isdCode']")));
	        SelectISDCode.sendKeys(ISDCode);
	        Thread.sleep(2000);
	        WebElement IndiaISDCode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[normalize-space(text())= 'India(+91)']")));
	        IndiaISDCode.click();
	        WebElement MobileNumber = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='phoneNo']")));
	        MobileNumber.sendKeys(MobileNo);
	        WebElement EnterPassword = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname='password']")));
	        EnterPassword.sendKeys(Password);
	        WebElement ConfirmPassword = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@formcontrolname= 'confirmPassword']")));
	        ConfirmPassword.sendKeys(Confirmpassword);

	        // Click the SIGNUP button
	        WebElement SIGNUP = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[normalize-space(text())= 'SIGNUP']")));
	        Thread.sleep(3000);

	        SIGNUP.click();
	        Thread.sleep(3000);
	        
	        String screenshotPath = getScreenshot(driver, "Screenshot");
            test.info("Info of create an account", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());

	        // Verify successful account creation
	        WebElement  DownloadbuttonafterSIGNUP= driver.findElement(By.xpath("//*[text()= 'download']"));
	        if (DownloadbuttonafterSIGNUP.isDisplayed()) {
	            test.pass("Account created successfully.");
	        } else {
	            test.fail("Account creation failed.");
	           
               
            }
        } catch (Exception e) {
            String screenshotPath = getScreenshot(driver, "exceptionOccurredScreenshot");
            test.fail("Exception occurred: " + e.getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            throw e; // rethrow the exception after logging
        }}}