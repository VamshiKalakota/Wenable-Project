package com.weguard.ui;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

public class Base {
    protected WebDriver driver; // which is used to control the browser and perform actions like clicking, navigating, and retrieving data
    protected Properties data; // which is used to manage configuration data or test data in key-value pairs.
    protected ExtentReports extent; //which is used to generate and manage test reports.
    protected ExtentTest test; //It allows you to log test information, such as pass/fail status, test steps, screenshots, and other details

    @BeforeClass
    public void setUp() throws IOException, InterruptedException {
        // Initialise ExtentReports
        ExtentReportManager.initialize();
        extent = ExtentReportManager.getExtentReports();

        // Load properties file
        data = new Properties();
        FileInputStream fis = new FileInputStream("src/test/java/com/weguard/ui/application.properties");
        data.load(fis);

        // Set ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver");

        // Initialise WebDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }
    
	public String getScreenshot(WebDriver driver, String screenshotName) throws IOException {
		String dateName = new SimpleDateFormat("dd-MM-yyyy_HH.mm.ss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = System.getProperty("user.dir") + "/Failed_Screenshots/" + screenshotName + dateName
				+ ".png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		return destination;
	}

	@AfterTest
	public void afterTest() {
		extent.flush();
	}

    @AfterClass
    public void tearDown() throws InterruptedException {
        // Close the WebDriver
    	 Thread.sleep(10000);
        if (driver != null) {
            driver.quit();
        }

        // Flush ExtentReports
        ExtentReportManager.flushReport();
    }
}