package com.wenable.enterprise;

import org.testng.annotations.Test;
import io.restassured.path.json.JsonPath;
import io.restassured.http.ContentType;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DeviceDetailsView extends NormalUserLogin {
    private String[] accountinfo;

    @Test(priority = 1)
    public void getandroiddevicedata() {
        String baseURL = System.getenv("QA_BASEURL");
        RestAssured.baseURI = baseURL;
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];

        try {
            String Data = given().log().all()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + jwtToken)
                .when()
                .get("/enterprise/rest/v3/device/android/64f706ededfc5c75acb7095e")
                .then().assertThat().statusCode(200)
                .log().all()
                .extract().response().asString();

            // Extract and store information
            JsonPath DATA = new JsonPath(Data);
            String DEVICEID = DATA.getString("deviceID");
            String actCode = DATA.getString("activationCode");
            String pctCode = DATA.getString("productActivationCode");
            String pId = DATA.getString("policyId");
            accountinfo = new String[]{DEVICEID, actCode, pctCode, pId};
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions as needed
        }
    }

    
    public String[] getAccountInfo() {
        return accountinfo;
    }

   // @Test(priority = 2)
    public void rebootcommand() {
        getandroiddevicedata();

        String baseURL = System.getenv("QA_BASEURL");

        RestAssured.baseURI = baseURL;
        String command = "{\r\n" +
                "  \"topic\": \"354386270942191_YNDS3_C-QXPW0\",\r\n" +
                "  \"type\": \"RESTART_DEVICE\",\r\n" +
                "  \"isLicenseLevel\": false,\r\n" +
                "  \"pId\": \"" + accountinfo[3] + "\",\r\n" +
                "  \"actCode\": \"" + accountinfo[1] + "\",\r\n" +
                "  \"pActCode\": \"" + accountinfo[2] + "\",\r\n" +
                "  \"priority\": \"high\",\r\n" +
                "  \"id\": 89641884\r\n" +
                "}";

        try {
            given().log().all()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + login())
                .body(command)
                .when()
                .post("/enterprise/rest/weguard-v2/fcmUpdate")
                .then().assertThat().statusCode(200)
                .log().all();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions as needed
        }
    }
   // @Test(priority=3)
	public void devicelockcommand(){
    	getandroiddevicedata();
    	Properties properties = new Properties();

	    try {
	        FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
	        // Load properties from the application.properties file
	        properties.load(fis);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    String TOPIC = properties.getProperty("topic");

		 String baseURL = System.getenv("QA_BASEURL");
		 RestAssured.baseURI = baseURL;
		String command="{\r\n"
				+ "  \"topic\": \""+ TOPIC + "\",\r\n"
				+ "  \"type\": \"LOCK_DEVICE\",\r\n"
				+ "  \"isLicenseLevel\": false,\r\n"
				+ "  \"pId\": \"" + accountinfo[3] + "\",\r\n"
				+ "  \"actCode\": \"" +accountinfo[1]+ "\",\r\n"
				+ "  \"pActCode\": \"" +accountinfo[2] + "\",\r\n"
				+ "  \"priority\": \"high\",\r\n"
				+ "  \"id\": 36590299\r\n"
				+ "}";
		
		given().log().all()
        .contentType(ContentType.JSON)
        .header("Authorization", "Bearer " + login())
        .body(command)
		.when()
		.post("/enterprise/rest/weguard-v2/fcmUpdate")
		
		.then().assertThat().statusCode(200).log().all();
		
		
	}
   //@Test(priority=4)
	public void findmydevice(){
		getandroiddevicedata();
    	Properties properties = new Properties();

	    try {
	        FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
	        // Load properties from the application.properties file
	        properties.load(fis);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    String TOPIC = properties.getProperty("topic");
		 String baseURL = System.getenv("QA_BASEURL");
		 RestAssured.baseURI = baseURL;
		String command="{\r\n"
				+ "  \"topic\": \"" + TOPIC + "\",\r\n"
				+ "  \"type\": \"FCM_FIND_MY_DEVICE\",\r\n"
				+ "  \"isLicenseLevel\": false,\r\n"
				+ "  \"pId\": \""+accountinfo[3]+"\",\r\n"
				+ "  \"actCode\": \""+accountinfo[1]+"\",\r\n"
				+ "  \"pActCode\": \""+accountinfo[2]+"\",\r\n"
				+ "  \"priority\": \"high\",\r\n"
				+ "  \"message\": null,\r\n"
				+ "  \"id\": 94989422\r\n"
				+ "}";
		
		given().log().all()
        .contentType(ContentType.JSON)
        .header("Authorization", "Bearer " + login())
        .body(command)
		.when()
		.post("/enterprise/rest/weguard-v2/fcmUpdate")
		
		.then().assertThat().statusCode(200).log().all();
		
		
	}
	 // @Test(priority=5)
		public void stopfindmydevice(){
			getandroiddevicedata();
	    	Properties properties = new Properties();

		    try {
		        FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
		        // Load properties from the application.properties file
		        properties.load(fis);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }

		    String TOPIC = properties.getProperty("topic");
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			String command="{\r\n"
					+ "  \"topic\": \""+ TOPIC + "\",\r\n"
					+ "  \"type\": \"FCM_STOP_FIND_MY_DEVICE\",\r\n"
					+ "  \"isLicenseLevel\": false,\r\n"
					+ "  \"pId\": \""+ accountinfo[3]+"\",\r\n"
					+ "  \"actCode\": \""+accountinfo[1]+"\",\r\n"
					+ "  \"pActCode\": \""+accountinfo[2]+"\",\r\n"
					+ "  \"priority\": \"high\",\r\n"
					+ "  \"message\": null,\r\n"
					+ "  \"id\": 42902968\r\n"
					+ "}";
			
			given().log().all()
	        .contentType(ContentType.JSON)
	        .header("Authorization", "Bearer " + login())
	        .body(command)
			.when()
			.post("/enterprise/rest/weguard-v2/fcmUpdate")
			
			.then().assertThat().statusCode(200).log().all();
			
			
		}
	//@Test(priority=5)
	public void adminlock(){
		
		getandroiddevicedata();
	    
		 String baseURL = System.getenv("QA_BASEURL");
		 RestAssured.baseURI = baseURL;
		 
		String command="{\r\n"
				+ "  \"action\": \"ADMIN_LOCK\",\r\n"
				+ "  \"deviceIds\": [\r\n"
				+ "    \"" + accountinfo[0] + "\"\r\n"
				+ "  ],\r\n"
				+ "  \"msg\": \"Your device is locked, please contact administrator\"\r\n"
				+ "}";
		
		given().log().all()
        .contentType(ContentType.JSON)
        .header("Authorization", "Bearer " + login())
        .body(command)
		.when()
		.post("enterprise/rest/v3/device/action")
		
		.then().assertThat().statusCode(200).log().all();
		
		
	}
	//@Test(priority=6)
	public void adminunlock(){
		
		getandroiddevicedata();
	    
		 String baseURL = System.getenv("QA_BASEURL");
		 RestAssured.baseURI = baseURL;
		 
		String command="{\r\n"
				+ "  \"action\": \"ADMIN_UNLOCK\",\r\n"
				+ "  \"deviceIds\": [\r\n"
				+ "    \"" + accountinfo[0] + "\"\r\n"
				+ "  ],\r\n"
				+ "  \"msg\": \"Your device is unlocked, Thank you!!!\"\r\n"
				+ "}";
		
		given().log().all()
        .contentType(ContentType.JSON)
        .header("Authorization", "Bearer " + login())
        .body(command)
		.when()
		.post("enterprise/rest/v3/device/action")
		
		.then().assertThat().statusCode(200).log().all();
		
		
	}
	//@Test(priority=7)
	public void clearkioskpassword(){
		getandroiddevicedata();
    	Properties properties = new Properties();

	    try {
	        FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
	        // Load properties from the application.properties file
	        properties.load(fis);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    String TOPIC = properties.getProperty("topic");
	    String baseURL = System.getenv("QA_BASEURL");
		 RestAssured.baseURI = baseURL;
		String command="{\r\n"
				+ "  \"topic\": \"" + TOPIC + "\",\r\n"
				+ "  \"type\": \"KIOSK_PASSWORD_RESET_DEVICE\",\r\n"
				+ "  \"isLicenseLevel\": false,\r\n"
				+ "  \"pId\": \""+accountinfo[3]+"\",\r\n"
				+ "  \"actCode\": \""+accountinfo[1]+"\",\r\n"
				+ "  \"pActCode\": \""+accountinfo[2]+"\",\r\n"
				+ "  \"priority\": \"high\",\r\n"
				+ "  \"id\": 42567184\r\n"
				+ "}";
		
		given().log().all()
        .contentType(ContentType.JSON)
        .header("Authorization", "Bearer " + login())
        .body(command)
		.when()
		.post("/enterprise/rest/weguard-v2/fcmUpdate")
		
		.then().assertThat().statusCode(200).log().all();
		
		
	}
	 //@Test(priority=8)
		public void getdeviceenrolledpolicydata() {
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			 
			given().log().all()
	       .contentType(ContentType.JSON)
	       .header("Authorization", "Bearer " + login())
			.when()
			.get("/enterprise/rest/weguard-v2/policy/64cc93d57fa1a20102b8de2d")
			
			.then().assertThat().statusCode(200).log().all();
			
			
		}
		//@Test(priority=9)
		public void getdeviceapps() {
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			 
			given().log().all()
	      .contentType(ContentType.JSON)
	      .header("Authorization", "Bearer " + login())
			.when()
			.get("/enterprise/rest/deviceapps/apps/354292954670605")
			
			.then().assertThat().statusCode(200).log().all();
			
			
		}
		//@Test(priority=10)
		public void getdevicenotes() {
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			 
			given().log().all()
	       .contentType(ContentType.JSON)
	       .header("Authorization", "Bearer " + login())
			.when()
			.get("/enterprise/rest/notes/354292954670605?page=1&limit=100")
			
			.then().assertThat().statusCode(200).log().all();
			
			
		}
		//@Test(priority=11)
		public void getdevicelevelbroadcasthistory() {
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			 
			given().log().all()
	       .contentType(ContentType.JSON)
	       .header("Authorization", "Bearer " + login())
			.when()
			.get("/enterprise/rest/broadcast/history/device/354292954670605?pageNo=1&pageSize=100&type=FCM_MESSAGE")
			
			.then().assertThat().statusCode(200).log().all();
			
		}
		//@Test(priority=12)
		public void getdevicescreensharehistory() {
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			 
			given().log().all()
	       .contentType(ContentType.JSON)
	       .header("Authorization", "Bearer " + login())
			.when()
			.get("/enterprise/rest/webrtc/screensharehistory/354292954670605?page=1&pageSize=100&email=chakrapani.bandhu@weguard.com")
			
			.then().assertThat().statusCode(200).log().all();
			
		}
		//@Test(priority=13)
		public void getdeviceevents() {
			
			getandroiddevicedata();
	    	
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			 
			 String value ="{\r\n"
			 		+ "  \"startDate\": 1694543400000,\r\n"
			 		+ "  \"endDate\": 1694629799999,\r\n"
			 		+ "  \"event\": \"All\",\r\n"
			 		+ "  \"logLevel\": \"All\",\r\n"
			 		+ "  \"deviceIds\": [\r\n"
			 		+ "    \""+accountinfo[0]+"\"\r\n"
			 		+ "  ],\r\n"
			 		+ "  \"policyIds\": []\r\n"
			 		+ "}";
			 
			given().log().all()
	       .contentType(ContentType.JSON)
	       .header("Authorization", "Bearer " + login())
	       .body(value)
			.when()
			.post("/enterprise/rest/weguard/logs/eventsPerAccount?page=1&size=100")
			
			.then().assertThat().statusCode(200).log().all();
			
		}
		//@Test(priority=14)
		public void getdevicelastcontacttime() {
			getandroiddevicedata();
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			  
			 String value ="{\r\n"
			 		+ "  \"deviceId\": \""+accountinfo[0]+"\",\r\n"
			 		+ "  \"lastContactTime\": \"2023-09-13T09:03:47.540Z\"\r\n"
			 		+ "}";
			 
			given().log().all()
	       .contentType(ContentType.JSON)
	       .header("Authorization", "Bearer " + login())
	       .body(value)
			.when()
			.put("/enterprise/rest/v3/device/last-contact-time")
			
			.then().assertThat().statusCode(200).log().all();
	}
		//@Test(priority=15)
		public void getdeviceappdatausagemodel() {
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			  
			given().log().all()
	       .contentType(ContentType.JSON)
	       .header("Authorization", "Bearer " + login())
	     
			.when()
			.get("/enterprise/rest/app/device/354292954670605")
			
			.then().assertThat().statusCode(200).log().all();
	}
		
		//@Test(priority=16)
		public void getdevicefcmupdate() {
			
			getandroiddevicedata();
	    	Properties properties = new Properties();

		    try {
		        FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
		        // Load properties from the application.properties file
		        properties.load(fis);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }

		    String TOPIC = properties.getProperty("topic");
			 String baseURL = System.getenv("QA_BASEURL");
			 RestAssured.baseURI = baseURL;
			  String value="{\r\n"
			  		+ "  \"topic\": \""+ TOPIC + "\",\r\n"
			  		+ "  \"type\": \"FCM_APK_DU\",\r\n"
			  		+ "  \"isLicenseLevel\": false,\r\n"
			  		+ "  \"pId\": \""+accountinfo[3]+"\",\r\n"
			  		+ "  \"actCode\": \""+accountinfo[1]+"\",\r\n"
			  		+ "  \"pActCode\": \""+accountinfo[2]+"\",\r\n"
			  		+ "  \"priority\": \"high\"\r\n"
			  		+ "}";
			given().log().all()
	       .contentType(ContentType.JSON)
	       .header("Authorization", "Bearer " + login())
	       .body(value)
			.when()
			.post("/enterprise/rest/weguard-v2/fcmUpdate")
			
			.then().assertThat().statusCode(200).log().all();
	}
	}



    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
	    
	    
	    
		
		
	
