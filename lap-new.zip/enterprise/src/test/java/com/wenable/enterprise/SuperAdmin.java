package com.wenable.enterprise;

import io.restassured.http.ContentType;
import static io.restassured.RestAssured.given;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class SuperAdmin extends SuperAdminLogin {
	
	//@Test(priority = 1)
	public void listofsuperadmin() {
		
		given()
        .contentType(ContentType.JSON)
      
        .header("Authorization", "Bearer " + successLogincase())
		
		.when()
			.get("enterprise/rest/users")
		.then()
			.assertThat()
			.statusCode(200)
			.log().all();
	}
	//@Test(priority = 2)
	public void CreateSuperAdmin() {
		Properties properties = new Properties();

        try {
            
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
         // Load properties from the application.properties file
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
       
     // Extracting property values
        String EMAILID = properties.getProperty("emailId");
        String FNAME = properties.getProperty("fName");
        String LNAME = properties.getProperty("lName");
        String COMPANYNAME = properties.getProperty("companyName");
        String USERNAME = properties.getProperty("userName");
        String ROLE = properties.getProperty("role"); 
        String PASSWORD = properties.getProperty("password");
        String CONTACTNUMBER = properties.getProperty("contactNumber");
        String COUNTRYCODE = properties.getProperty("countryCode");
        String PHONENUMBER = properties.getProperty("phoneNumber");

      String requestBody =  "{\r\n"
        + "    \"emailId\": \"" + EMAILID + "\",\r\n"
        + "    \"fName\": \"" + FNAME + "\",\r\n"
        + "    \"lName\": \"" + LNAME + "\",\r\n"
        + "    \"companyName\": \"" + COMPANYNAME + "\",\r\n"
        + "    \"userName\": \"" + USERNAME + "\",\r\n"
        + "    \"role\": \"" + ROLE + "\",\r\n"
        + "    \"password\": \""+ PASSWORD + "\",\r\n"
        + "    \"contactNumber\": \"" +CONTACTNUMBER + "\",\r\n"
        + "    \"phoneNumber\": \"" +PHONENUMBER+ "\",\r\n"
        + "    \"countryCode\": \"" +COUNTRYCODE+ "\"\r\n"
        + "    \r\n"
        + "}";

		given()
        .contentType(ContentType.JSON)
        .body(requestBody)
        .header("Authorization", "Bearer " + successLogincase())
		
		.when()
			.post("enterprise/rest/users/create")
		.then().log().all()
			.assertThat()
			.statusCode(200);
			
	}
}
