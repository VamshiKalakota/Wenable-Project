package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


import static io.restassured.RestAssured.given;

public class Data_Usage extends NormalUserLogin {
	private ExtentTest test;

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }
	@Test(priority=1)
	public void Wifi_DataUsage() {
		 test = Extentreportmanager.createTest("Wifi_DataUsage Test");
	        test.assignAuthor("Vamshi");

	        String[] loginInfo = loginTest();
	        String jwtToken = loginInfo[0];
	        if (jwtToken != null) {
	            Response response = given()
	                    .log().all()
	                    .contentType(ContentType.JSON)
	                    .header("Authorization", "Bearer " + jwtToken)
	                    .when()
	                    .get("enterprise/rest/app/datausage?page=1&size=100&type=WIFI")
	                    .then()
	                    .log().all()
	                    .extract().response();

	            int statuscode = response.getStatusCode();

	            if (statuscode == 200) {
	                test.log(Status.PASS, "Device Data usage(Wifi) is successfully fetched");
	                // Log the response data
	                test.log(Status.INFO, "Response Data: " + response.asString());
	            } else {
	                test.log(Status.FAIL, "Failed to fetch the Device Data usage(Wifi):" + statuscode);
	                // Log the response data
	                test.log(Status.INFO, "Response Data: " + response.asString());
	            }
	        }
	}
	@Test(priority=2)
	public void Network_DataUsage() {
		 test = Extentreportmanager.createTest("Network_DataUsage Test");
	        test.assignAuthor("Vamshi");

	        String[] loginInfo = loginTest();
	        String jwtToken = loginInfo[0];
	        if (jwtToken != null) {
	            Response response = given()
	                    .log().all()
	                    .contentType(ContentType.JSON)
	                    .header("Authorization", "Bearer " + jwtToken)
	                    .when()
	                    .get("enterprise/rest/app/datausage?page=1&size=100&type=NETWORK")
	                    .then()
	                    .log().all()
	                    .extract().response();

	            int statuscode = response.getStatusCode();

	            if (statuscode == 200) {
	                test.log(Status.PASS, "Device Data usage(Network) is successfully fetched");
	                // Log the response data
	                test.log(Status.INFO, "Response Data: " + response.asString());
	            } else {
	                test.log(Status.FAIL, "Failed to fetch the Device Data usage(Network):" + statuscode);
	                // Log the response data
	                test.log(Status.INFO, "Response Data: " + response.asString());
	            }
	        }
	}
}
