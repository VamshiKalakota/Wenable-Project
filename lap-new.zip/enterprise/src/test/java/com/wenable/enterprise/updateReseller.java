package com.wenable.enterprise;

import org.testng.annotations.Test;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.*;


public class updateReseller extends SuperAdminLogin {
	
	public static void main (String args[]) {
		System.out.println("Hello");
		}

    @Test(priority = 1)
    public void getAllResellers() {
    	
    	
   
        String requestBody = "{\r\n"
        		+ "  \"role\": \"reseller_admin\",\r\n"
        		+ "  \"searchText\": null,\r\n"
        		+ "  \"distributorIds\": []\r\n"
        		+ "}";

    given()
            .contentType(ContentType.JSON)
            .body(requestBody)
            .header("Authorization", "Bearer " + successLogincase())            
        .when()
            .post("enterprise/rest/users/all/users?page=1&size=100")
        .then()
        .assertThat()
            .statusCode(200)
            
            .log().all();
           
    }
    
  
    @Test(priority = 2)
    public void updateResellers() {
    	Properties properties = new Properties();

        try {
            
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
         // Load properties from the application.properties file
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
       
     // Extracting property values
        String Username = properties.getProperty("ReselleruserName");
        String id = properties.getProperty("Resellerid");
        String companyname = properties.getProperty("ResellercompanyName");
        String FirstName= properties.getProperty("ResellerfirstName");
        String LastName = properties.getProperty("ResellerlastName");
        String PhoneNumber = properties.getProperty("ResellerphoneNumber");
        String CountryCode = properties.getProperty("ResellercountryCode");
        String ContactNumber = properties.getProperty("ResellercontactNumber");
        String Region = properties.getProperty("Resellerregion");
        String Email = properties.getProperty("Reselleremail");
        String MarketingEmails = properties.getProperty("ResellermarketingEmails");
        
        String requestBody = "{\r\n" +
                "  \"id\": \"" + id + "\",\r\n" +
                "  \"userName\": \"" + Username + "\",\r\n" +
                "  \"companyName\": \"" + companyname + "\",\r\n" +
                "  \"firstName\": \"" + FirstName + "\",\r\n" +
                "  \"lastName\": \"" + LastName + "\",\r\n" +
                "  \"phoneNumber\": \"" + PhoneNumber + "\",\r\n" +
                "  \"countryCode\": \"" + CountryCode + "\",\r\n" +
                "  \"contactNumber\": \"" + ContactNumber + "\",\r\n" +
                "  \"region\": \"" + Region + "\",\r\n" +
                "  \"email\": \"" + Email + "\",\r\n" +
                "  \"marketingEmails\": [\r\n" +
                "    \"" + MarketingEmails + "\"\r\n" +
                "  ]\r\n" +
                "}";
        
      given()
            .contentType(ContentType.JSON)
            .body(requestBody)
            .header("Authorization", "Bearer " + successLogincase())
            
        .when()
            .post("enterprise/rest/users/update/user")
        .then().assertThat()
      
        .statusCode(200)
            .log().all();
       
    }
    @Test(priority = 3)
    public void ResetPWDforReseller() {
    	Properties properties = new Properties();

        try {
            
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
         // Load properties from the application.properties file
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
       
     // Extracting property values
        String USERNAME = properties.getProperty("RESELLERPWDUSERNAME");
        String PASSWORD = properties.getProperty("RESELLERPWD");
    	
   
        String requestBody = "{\r\n"
        		+ "  \"userName\": \"" + USERNAME + "\",\r\n"
        		+ "  \"password\": \""+ PASSWORD + "\"\r\n"
        		+ "}";

    given()
            .contentType(ContentType.JSON)
            .body(requestBody)
            .header("Authorization", "Bearer " + successLogincase())
            
        .when()
            .post("enterprise/rest/users/reset/password")
        .then()
        .assertThat()
            .statusCode(200)
            
            .log().all();
           
    }
    
    }