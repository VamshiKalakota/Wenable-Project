package com.wenable.enterprise;

import org.testng.annotations.Test;
import io.restassured.http.ContentType;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import static io.restassured.RestAssured.*;

public class Deletedevicelessaccounts extends SuperAdminLogin{
	
	@Test(priority=1)
public void deleteallcustomeraccounts() {
	Properties properties = new Properties();
	
	try {
		FileInputStream fis= new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
				properties.load(fis);
	}catch(IOException e) {
	     e.printStackTrace();
	}
	    String emaillist =properties.getProperty("emaillist");
	    
	String emailrequest= "{\r\n"
			+ "  \"emailList\": [\r\n"
			+ "    \"" + emaillist + "\"\r\n"
			+ "  ]\r\n"
			+ "}";
	given().log().all()
	.contentType(ContentType.JSON)
	.body(emailrequest)
	.header("Authorization", "Bearer " + successLogincase())
	
	.when()
	.delete("enterprise/rest/_admin/clean")
	.then().assertThat().statusCode(200).log().all();
}
}
