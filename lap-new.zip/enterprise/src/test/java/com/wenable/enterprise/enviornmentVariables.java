package com.wenable.enterprise;

public class enviornmentVariables {
    public static void main(String[] args) {
        String userName = System.getenv("WEGUARD_USER");
        String password = System.getenv("WEGUARD_PASS");
        String baseURL = System.getenv("QA_BASEURL");
        String logLevel = System.getenv("LOG_LEVEL");
        String email = System.getenv("USER_EMAIL");
        
        if (userName != null) {
            System.out.println("User Name: " + userName);
        }
        
        if (password != null) {
            System.out.println("Password: " + password);
        }
        
        if (baseURL != null) {
            System.out.println("Base URL: " + baseURL);
        }
        
        if (logLevel != null) {     
                System.out.println("Log Level: " + logLevel);
        }
        if (email != null) {     
            System.out.println("email: " + email);
    }
        else {
        	Exception e = null;
        	System.out.println(e);
        }
    }
}
