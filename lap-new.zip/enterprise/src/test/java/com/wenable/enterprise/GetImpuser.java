package com.wenable.enterprise;


import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.*;

public class GetImpuser extends SuperAdminLogin {
    ExtentTest test;
    @Test
    public void getImpuser() {
       
        String email = System.getenv("USER_EMAIL");
        String baseURL = System.getenv("QA_BASEURL");

        RestAssured.baseURI = baseURL;

        String rqsemail = "{\r\n"
                + "  \"userEmail\": \""+ email + "\"\r\n"
                + "}";

        given()
            .contentType(ContentType.JSON)
            .header("Authorization", "Bearer " + successLogincase())
            .body(rqsemail)
        .when()
            .post("/enterprise/rest/users/getimpuser")
        .then()
            .assertThat()
            .statusCode(200)
            .log().all();

      
    }

    @Test(priority = 2)
    public void getdashboarddata() {
    

        given()
            .contentType(ContentType.JSON)
            .header("Authorization", "Bearer " + successLogincase())
            
        .when()
            .get("enterprise/rest/dashboard/O4RLE/HOTF-0AO57")
        .then()
            .log().all() 
            .assertThat()
            .statusCode(200);
    }
}
