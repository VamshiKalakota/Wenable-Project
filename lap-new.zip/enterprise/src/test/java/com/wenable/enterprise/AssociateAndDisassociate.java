package com.wenable.enterprise;

import org.testng.annotations.Test;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.given;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class AssociateAndDisassociate extends SuperAdminLogin {

	@Test(priority = 1)
	public void Associate() {

		Properties properties = new Properties();

		try {

			FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
			// Load properties from the application.properties file
			properties.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		String AssociatedistributorId = properties.getProperty("distributorId");
		String AssociatepartnerId = properties.getProperty("partnerId");
		String transferAccountIds = properties.getProperty("transferAccountIds");
		String ExistingdistributorID = properties.getProperty("existingdistributorId");

		String requestbody = "{\r\n" + "  \"distributorId\": \"" + AssociatedistributorId + "\",\r\n"
				+ "  \"partnerId\": \"" + AssociatepartnerId + "\",\r\n" + "  \"transferAccountIds\": [\r\n" + "    \""
				+ transferAccountIds + "\"\r\n" + "  ]\r\n" + "}";

		if (AssociatedistributorId.equals(ExistingdistributorID)) {
			throw new RuntimeException("Cannot transfer to the same distributor ID.");
		}
		given().log().all().contentType(ContentType.JSON).header("Authorization", "Bearer " + successLogincase())
				.body(requestbody)

				.when().post("enterprise/rest/users/transfer/users").then().assertThat().statusCode(200).log().all();

	}

}
