package com.wenable.enterprise;

import org.testng.annotations.Test;

import io.restassured.path.json.*;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class SuperAdminLogin {

	@Test(priority =1)
	public void loginToken() {
		successLogincase();
	}
    
    public String successLogincase() {
        
        String baseURL = System.getenv("QA_BASEURL");
        String userName = System.getenv("WEGUARD_USER");
        String password = System.getenv("WEGUARD_PASS");
        
        RestAssured.baseURI = baseURL;

        String requestBody = "{\r\n"
        		+ "  \"userName\": \"" + userName + "\",\r\n"
        		+ "  \"password\": \"" + password + "\"\r\n"
        		+ "}";

       String Token = given()
            .contentType(ContentType.JSON)
            .body(requestBody)
        .when()
            .post("/enterprise/rest/users/login")
        .then()          
            .assertThat()
            .statusCode(200)
            .log().all().extract().response().asString();
       
       JsonPath jwtToken = new JsonPath(Token);
       String JT= jwtToken.getString("entity.jwtToken");
       System.out.println(JT);
       
       return JT;
    }
    
    //@Test(priority = 2)
    public void failureLogincase() {
        
        String baseURL = System.getenv("QA_BASEURL");
        String userName = System.getenv("WEGUARD_USER");
        String password = System.getenv("WEGUARD_PASS");
        
        RestAssured.baseURI = baseURL;

        String requestBody = "{\r\n"
        		+ "  \"userName\": \"" + userName + "\",\r\n"
        		+ "  \"password\": \"" + password + "\"\r\n"
        		+ "}";

        given()
            .contentType(ContentType.JSON)
            .body(requestBody)
        .when()
            .post("/enterprise/rest/users/login")
        .then()         
            .assertThat()
            .statusCode(400);
    }
}





