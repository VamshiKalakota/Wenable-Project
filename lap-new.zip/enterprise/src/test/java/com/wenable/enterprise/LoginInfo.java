package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.path.json.JsonPath;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import static io.restassured.RestAssured.given;

public class LoginInfo {
	private ExtentTest test;
	private String jwtToken;
	private String actCode;
	private String PactCode;
	private String AccountID;

	@BeforeSuite
	public void setUp() {
		// Initialize Extent Report for reporting
		Extentreportmanager.initialize();
	}

	@AfterSuite
	public void tearDown() {
		// Close and save the Extent Report
		Extentreportmanager.flushReport();
	}

	@Test(priority = 1)
	public void loginTest() {
		// Create a test case in the Extent Report
		test = Extentreportmanager.createTest("Login Test");
		// Assign an author to the test case
		test.assignAuthor("Vamshi");

		// Call the login method to retrieve JWT Token and ActCode
		String[] loginInfo = login();

		if (loginInfo != null && loginInfo.length == 4) {
			jwtToken = loginInfo[0];
			actCode = loginInfo[1];
			PactCode = loginInfo[2];
			AccountID = loginInfo[3];
			// Log login information in the Extent Report
			test.log(Status.INFO, "Login passed with JWT Token: " + jwtToken + ", Act Code: " + actCode
					+ ", Pact Code: " + PactCode + ", Account ID: " + AccountID);
		}
	}

	public String[] login() {

		Properties properties = new Properties();
		FileInputStream fis = null;

		try {
			fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
			properties.load(fis);// Load properties from a file
		} catch (IOException e) {
			e.printStackTrace();
			// Handle the exception properly, e.g., log the error or throw an exception
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		// Get login credentials from properties
		String email = properties.getProperty("normaluserName");
		String password = properties.getProperty("normalpassword");
		String baseURI = properties.getProperty("BaseURL");
		RestAssured.baseURI = baseURI; // Set the base URI for REST Assured

		// Prepare the login request body
		String getLogin = "{\r\n" + "  \"userName\": \"" + email + "\",\r\n" + "  \"password\": \"" + password
				+ "\"\r\n" + "}";

		// Send a POST request to login
		Response response = given().contentType(ContentType.JSON).body(getLogin).when()
				.post("/enterprise/rest/users/login").then().log().all().extract().response();

		int statusCode = response.getStatusCode();

		if (statusCode == 200) {
			// Extract and log the login information on success
			JsonPath jwtJson = new JsonPath(response.asString());
			jwtToken = jwtJson.getString("entity.jwtToken");
			actCode = jwtJson.getString("entity.activationCode");
			PactCode = jwtJson.getString("entity.productActivationCode");
			AccountID = jwtJson.getString("entity.userData.accountId");

			// Log the successful login in the Extent Report
			test.log(Status.PASS, "Login Successfully: JWT Token - " + jwtToken + ", Act Code - " + actCode
					+ ", Pact Code - " + PactCode + ", AccID - " + AccountID);
			return new String[] { jwtToken, actCode, PactCode, AccountID };
		} else {
			// Log login failure in the Extent Report
			test.log(Status.FAIL, "Login failed with status code: " + statusCode);
			test.log(Status.FAIL, "Invalid Credentials: " + email);
			test.log(Status.FAIL, "Invalid Credentials: " + password);
			return null;
		}
	}
}
