package com.wenable.enterprise;


import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;


public class DashBoard extends NormalUserLogin {
	private ExtentTest test;

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }

  
	@Test(priority = 1)
    public void getdashboarddata() {
        test = Extentreportmanager.createTest("Get Dashboard Data Test"); // Create a new ExtentTest
        test.assignAuthor("Vamshi");
        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
            
        Response response = given().log().all().contentType(ContentType.JSON).header("Authorization", "Bearer " + jwtToken).when().get("enterprise/rest/dashboard/PSRW3/COMN-1OKFK").then().log().all().extract().response();

        int statusCode = response.getStatusCode();

        if (statusCode == 200) {
            test.log(Status.PASS, "Dashboard data is successfully updated");
        } else {
            test.log(Status.FAIL, "Failed to get dashboard data with status code: " + statusCode);
        }
    }

    //@Test(priority = 3)
    public void getrecentactivity() {
        test = Extentreportmanager.createTest("Get Recent Activity Test"); // Create a new ExtentTest
        test.assignAuthor("Vamshi");
        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
            
        Response response = given().log().all().contentType(ContentType.JSON).header("Authorization", "Bearer " + jwtToken).when().get("enterprise/rest/auditlogs/PSRW3/COMN-1OKFK?page=1&limit=100&start=2023-09-04T00:00:00.000Z&end=2023-09-11T23:59:59.999Z").then().log().all().extract().response();

        int statusCode = response.getStatusCode();

        if (statusCode == 200) {
            test.log(Status.PASS, "Received Recent Activity");
        } else {
            test.log(Status.FAIL, "Failed to get recent activity with status code: " + statusCode);
        }
    }

    //@Test(priority = 4)
    public void getuserdata() {
        test = Extentreportmanager.createTest("Get User Data Test"); // Create a new ExtentTest
        test.assignAuthor("Vamshi");
        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
           
        Response response = given().log().all().contentType(ContentType.JSON).header("Authorization", "Bearer " + jwtToken).when().get("/enterprise/rest/users/user").then().log().all().extract().response();

        int statusCode = response.getStatusCode();

        if (statusCode == 200) {
            test.log(Status.PASS, "Received User Data");
        } else {
            test.log(Status.FAIL, "Failed to get user data with status code: " + statusCode);
        }
    }}