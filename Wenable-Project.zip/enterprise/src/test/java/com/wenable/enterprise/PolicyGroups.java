package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class PolicyGroups extends NormalUserLogin {
    private ExtentTest test;
    

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }

    @Test(priority = 1)
    public void getpolicyinfo() {
        test = Extentreportmanager.createTest("Get policy info Test");
        test.assignAuthor("Vamshi");
        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
            String actCode = loginInfo[1];
            String PactCode = loginInfo[2];
        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        RestAssured.baseURI = baseurl;

        Response response = given().log().all()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + jwtToken)
                .when()
                .get("/enterprise/rest/v3/policy/all?page=1&size=100&deviceCount=true&impersonator=false")
                .then()
                .log().all()
                .extract().response();

        int statusCode = response.getStatusCode();

        if (statusCode == 200) {
            test.log(Status.PASS, "Retrieved all the policies successfully");
            String responseBody = response.asString();
            test.log(Status.INFO, "Response Data: " + response.asString());

            JsonPath jsonPath = new JsonPath(responseBody);

            List<String> policyIds = jsonPath.getList("list.id");

            for (String policyId : policyIds) {
                System.out.println("Policy ID: " + policyId);
            }

            test.log(Status.INFO, "Policy IDs: " + policyIds);
        } else {
            test.log(Status.FAIL, "Failed to fetch all policies with status code: " + statusCode);
        }
    }




    //@Test(priority = 2)
    public void getdefaultkioskpolicyinfo() {
        test = Extentreportmanager.createTest("Get default kiosk policy");
        test.assignAuthor("Vamshi");
        String baseurl = System.getenv("QA_BASEURL");
        RestAssured.baseURI = baseurl;

        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
            String actCode = loginInfo[1];
            String PactCode = loginInfo[2];

        Response response = given()
            .log().all()
            .header("Authorization", "Bearer " + jwtToken)
            .contentType(ContentType.JSON)
            .when()
            .get("enterprise/rest/weguard-v2/policy/64cc93d57fa1a20102b8de2d")
            .then()
            .assertThat().statusCode(200)
            .log().all()
            .extract().response();

        int statuscode = response.getStatusCode();

        if (statuscode == 200) {
            test.log(Status.PASS, "Default Android Kiosk policy details are successfully fetched");
            // Log the response data
            test.log(Status.INFO, "Response Data: " + response.asString());
        } else {
            test.log(Status.FAIL, "Failed to fetch the Default Android Kiosk policy details:" + statuscode);
            // Log the response data
            test.log(Status.INFO, "Response Data: " + response.asString());
        }
    }


	
	
	@Test(priority=3)
	public  void clonedefaultkioskpolicy() {
		test =Extentreportmanager.createTest("Clone a policy");
		test.assignAuthor("Vamshi");
		String  baseurl= System.getenv("QA_BASEURL");
		RestAssured.baseURI=baseurl;
		String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
            String actCode = loginInfo[1];
            String PactCode = loginInfo[2];
		String body ="{\r\n"
				+ "  \"groupId\": \"9LX20_A1EX-VDFA3_Vamshi_Kiosk\",\r\n"
				+ "  \"groupDisplayName\": \"Vamshi_Kiosk\",\r\n"
				+ "  \"activation\": \"9LX20\",\r\n"
				+ "  \"productActivation\": \"A1EX-VDFA3\",\r\n"
				+ "  \"cloneGroupId\": null,\r\n"
				+ "  \"type\": \"ANDROID_KIOSK\",\r\n"
				+ "  \"clonedFrom\": \"64cc93d57fa1a20102b8de2d\",\r\n"
				+ "  \"clonedFromName\": \"Default Android Kiosk\"\r\n"
				+ "}";
		
		Response response =given().log().all()
				.header("Authorization", "Bearer " + jwtToken)
				.body(body)
		.contentType(ContentType.JSON)
		.when()
		.get("https://qa-cloud-gw.weguard.io/enterprise/rest/v3/policy/all?page=1&size=100&deviceCount=true&impersonator=false")
		.then()
		.assertThat().statusCode(200)
		.log().all().extract().response();
		int statuscode = response.getStatusCode();
		
		if(statuscode == 200) {
			test.log(Status.PASS, "Policies are successfully fetched");
		}else {
			test.log(Status.FAIL, "Failed to fecth the policy groups:" + statuscode);
		}
		
	}
	
}
