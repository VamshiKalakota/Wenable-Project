package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class Devicesmodule extends NormalUserLogin {
    private ExtentTest test;
    

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }

    @Test(priority = 1)
    public void getdevices() {
        test = Extentreportmanager.createTest("getdevices Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        RestAssured.baseURI = baseurl;
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];

        String body = "{\r\n"
                + "  \"search\": null,\r\n"
                + "  \"provisioned\": true,\r\n"
                + "  \"replaced\": null,\r\n"
                + "  \"lost\": null,\r\n"
                + "  \"stolen\": null,\r\n"
                + "  \"unEnrolled\": null,\r\n"
                + "  \"active\": null,\r\n"
                + "  \"policyIdList\": null\r\n"
                + "}";

       
        

        int statusCode = given().log().all()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + jwtToken)
                .body(body)
                .when()
                .post("/enterprise/rest/v3/device/all?page=1&size=100")
                .then()
                .log().all()
                .assertThat().extract().statusCode();

        if (statusCode == 200) {
            test.log(Status.PASS, "Provisioned devices are retrieved successfully");
        } else {
            test.log(Status.FAIL, "Failed to load devices check failed with status code: " + statusCode);
        }
    }



    @Test(priority = 2)
    public void getunprovisioneddevices() {
        test = Extentreportmanager.createTest("Get Unprovisioned Devices Test");
        test.assignAuthor("Vamshi_QA"); // Corrected the author name

        String baseURL = System.getenv("QA_BASEURL");
        RestAssured.baseURI = baseURL;
        // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];
        String body = "{\r\n"
                + "  \"search\": null,\r\n"
                + "  \"provisioned\": false,\r\n"
                + "  \"replaced\": null,\r\n"
                + "  \"lost\": null,\r\n"
                + "  \"stolen\": null,\r\n"
                + "  \"unEnrolled\": null,\r\n"
                + "  \"active\": null,\r\n"
                + "  \"policyIdList\": null\r\n"
                + "}";

        Response response = given()
            .log().all()
            .contentType(ContentType.JSON)
            .header("Authorization", "Bearer " +jwtToken)
            .body(body)
            .when()
            .post("/enterprise/rest/v3/device/all?page=1&size=100");

        int statusCode = response.getStatusCode();

        if (statusCode == 200) {
            test.log(Status.PASS, "Get Unprovisioned Devices request is successful");
        } else {
            test.log(Status.FAIL, "Get Unprovisioned Devices request failed with status code: " + statusCode);
        }
    }}

//    //@Test(priority = 3)
//    public void deletedevice() {
//        test = Extentreportmanager.createTest("Delete Device Test");
//        test.assignAuthor("Vamshi_QA"); // Corrected the author name
//
//        String baseURL = System.getenv("QA_BASEURL");
//        RestAssured.baseURI = baseURL;
//
//        int statusCode = given().log().all()
//            .contentType(ContentType.JSON)
//            .header("Authorization", "Bearer " + loginTest())
//            .when()
//            .delete("/enterprise/rest/weguard-v2/delete/357759080382336?suspend=false&wcm=false")
//            .then()
//            .log().all()
//            .extract().statusCode();
//
//        if (statusCode == 200) {
//            test.log(Status.PASS, "Delete device request is successful");
//        } else {
//            test.log(Status.FAIL, "Delete device request failed with status code: " + statusCode);
//        }
//    }
//
//    @Test(priority = 4)
//    public void checkwetalk() {
//        test = Extentreportmanager.createTest("Check WeTalk Test");
//        test.assignAuthor("Vamshi_QA"); // Corrected the author name
//
//        String baseURL = System.getenv("QA_BASEURL");
//        RestAssured.baseURI = baseURL;
//
//        int statusCode = given().log().all()
//            .contentType(ContentType.JSON)
//            .header("Authorization", "Bearer " +loginTest())
//            .when()
//            .get("enterprise/rest/v3/policy/android/64f95c29edfc5c75acb7205a/check-wetalk")
//            .then()
//            .log().all()
//            .extract().statusCode();
//
//        if (statusCode == 200) {
//            test.log(Status.PASS, "WeTalk check is successful");
//        } else {
//            test.log(Status.FAIL, "WeTalk check failed with status code: " + statusCode);
//        }
//    }
//
//
//	
//	//@Test(priority = 5)
//	public void authtoken() {
//	    test = Extentreportmanager.createTest("Auth Token Test");
//	    test.assignAuthor("Vamshi");
//
//	    String baseURL = System.getenv("QA_BASEURL");
//	    RestAssured.baseURI = baseURL;
//	    String auth = "{\r\n" +
//	            "  \"roomId\": \"OPS_anisha.yeginati+impersonate2@weguard.com_354386270942191_1695366695851\",\r\n" +
//	            "  \"identify\": \"OPS\",\r\n" +
//	            "  \"roomType\": \"peer-to-peer\"\r\n" +
//	            "}";
//
//	    int statusCode = given().log().all()
//	            .contentType(ContentType.JSON)
//	            .header("Authorization", "Bearer " + login())
//	            .body(auth)
//	            .when()
//	            .post("https://qa-cloud-gw.weguard.io/enterprise/rest/wetalk/video/authtoken")
//	            .then()
//	            .log().all()
//	            .extract().statusCode();
//
//	    if (statusCode == 200) {
//	        test.log(Status.PASS, "Auth token request is successful");
//	    } else {
//	        test.log(Status.FAIL, "Auth token request failed with status code: " + statusCode);
//	    }
//	}
//
//	//@Test(priority = 6)
//	public void fcmupdate() {
//	    test = Extentreportmanager.createTest("FCM Update Test");
//	    test.assignAuthor("Vamshi");
//
//	    String baseURL = System.getenv("QA_BASEURL");
//	    RestAssured.baseURI = baseURL;
//	    String auth = "{\r\n" +
//	            "  \"topic\": \"WT_YNDS3_ANIS-UTC4H_354386270942191\",\r\n" +
//	            "  \"type\": \"VIDEO_CALL\",\r\n" +
//	            "  \"isLicenseLevel\": false,\r\n" +
//	            "  \"actCode\": \"YNDS3\",\r\n" +
//	            "  \"pActCode\": \"ANIS-UTC4H\",\r\n" +
//	            "  \"message\": \"OPS_anisha.yeginati+impersonate2@weguard.com_354386270942191_1695367558523\",\r\n" +
//	            "  \"timestamp\": 1695367559994\r\n" +
//	            "}";
//
//	    int statusCode = given().log().all()
//	            .contentType(ContentType.JSON)
//	            .header("Authorization", "Bearer " + login())
//	            .body(auth)
//	            .when()
//	            .post("https://qa-cloud-gw.weguard.io/enterprise/rest/weguard-v2/fcmUpdate")
//	            .then()
//	            .log().all()
//	            .extract().statusCode();
//
//	    if (statusCode == 200) {
//	        test.log(Status.PASS, "FCM update request is successful");
//	    } else {
//	        test.log(Status.FAIL, "FCM update request failed with status code: " + statusCode);
//	    }
//	}}