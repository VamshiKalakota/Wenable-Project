package com.wenable.enterprise;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Extentreportmanager extends TestListenerAdapter {
    private static ExtentSparkReporter spark;
    private static ExtentReports extent;
    private static ExtentTest logger;

    public static void initialize() {
        String timestamp = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date());
        String reportName = "API_Test_Report_" + timestamp + ".html";

        spark = new ExtentSparkReporter(reportName);
        extent = new ExtentReports();
        extent.attachReporter(spark);
    }

    public static ExtentTest createTest(String testName) {
        return extent.createTest(testName);
    }

    public static void flushReport() {
        extent.flush();
    }

    @Override
    public void onTestSuccess(ITestResult tr) {
        logger = createTest(tr.getName());
        logger.log(Status.PASS, MarkupHelper.createLabel(tr.getName(), ExtentColor.GREEN));
    }

    @Override
    public void onTestFailure(ITestResult tr) {
        logger = createTest(tr.getName());
        logger.log(Status.FAIL, MarkupHelper.createLabel(tr.getName(), ExtentColor.RED));
        String screenshotPath = "C:\\Users\\vamshi.kalakota_wena\\Documents\\APITesting\\Screenshots\\" + tr.getName() + ".png";
        File f = new File(screenshotPath);
        if (f.exists()) {
            try {
                logger.fail("Screenshot is below:" + logger.addScreenCaptureFromPath(screenshotPath));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
