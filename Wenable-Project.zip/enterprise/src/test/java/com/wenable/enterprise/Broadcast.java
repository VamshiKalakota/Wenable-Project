package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class Broadcast extends NormalUserLogin {
    private ExtentTest test;

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }

    @Test(priority = 1)
    public void getlistofbroadcastmessages() {
        test = Extentreportmanager.createTest("getlistofbroadcastmessages Test");
        test.assignAuthor("Vamshi");

        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
            String actCode = loginInfo[1];
            String PactCode = loginInfo[2];
            
            String body="{\r\n"
            		+ "  \"actCode\": \""+ actCode +"\",\r\n"
            		+ "  \"pActCode\": \""+ PactCode +"\",\r\n"
            		+ "  \"type\": \"FCM_MESSAGE\"\r\n"
            		+ "}";

        if (jwtToken != null) {
            Response response = given()
                    .log().all()
                    .contentType(ContentType.JSON)
                    .header("Authorization", "Bearer " + jwtToken)
                    .body(body)
                    .when()
                    .post("/enterprise/rest/weguard-v2/messageHistory?page=1&pageSize=500")
                    .then()
                    .log().all()
                    .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Broadcast messages are successfully fetched");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to fetch the Broadcast messages:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
    }
    @Test(priority = 2)
    public void SendBroadcastRichTextMessages() {
        test = Extentreportmanager.createTest("SendBroadcastRichTextMessages Test");
        test.assignAuthor("Vamshi");

        String entity = sendBroadcastRichTextMessage();

        if (entity != null) {
            test.log(Status.PASS, "Broadcast rich text message is successfully sent");
            // Log the entity value
            test.log(Status.INFO, "Entity Value: " + entity);
        } else {
            test.log(Status.FAIL, "Failed to send Broadcast rich text message");
        }
    }

    public String sendBroadcastRichTextMessage() {
        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
        String entity = null;

        String body = "{\n"
                + "  \"textColor\": \"#ffffff\",\n"
                + "  \"bgColor\": \"#000\",\n"
                + "  \"textType\": \"rich\",\n"
                + "  \"title\": \"Gayatri\",\n"
                + "  \"body\": \"Taret is ready\"\n"
                + "}";

        if (jwtToken != null) {
            Response response = given()
                    .log().all()
                    .contentType(ContentType.JSON)
                    .header("Authorization", "Bearer " + jwtToken)
                    .body(body)
                    .when()
                    .post("/enterprise/rest/broadcast/message/save")
                    .then()
                    .log().all()
                    .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                JsonPath jwtJson = new JsonPath(response.asString());
                entity = jwtJson.getString("entity");
            }
        }

        return entity;
    }

    




    //@Test(priority = 3)
    public void SendBroadcastRichTextMessages2() {
        test = Extentreportmanager.createTest("SendBroadcastRichTextMessages2 Test");
        test.assignAuthor("Vamshi");

        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
        String actCode = loginInfo[1];
        String PactCode = loginInfo[2];

        String entity = sendBroadcastRichTextMessage();

        if (jwtToken != null) {
            String body = "{\n"
                    + "  \"topic\": \"9LX20_A1EX-VDFA3\",\n"
                    + "  \"type\": \"FCM_MESSAGE\",\n"
                    + "  \"isLicenseLevel\": true,\n"
                    + "  \"actCode\": \"" + actCode + "\",\n"
                    + "  \"pActCode\": \"" + PactCode + "\",\n"
                    + "  \"message\": \"{\\\"textColor\\\":\\\"#ffffff\\\",\\\"bgColor\\\":\\\"#000000\\\",\\\"textType\\\":\\\"rich\\\",\\\"title\\\":\\\"QATEAM\\\",\\\"body\\\":\\\"qwerty\\\",\\\"bMsgBodyRef\\\":\\\"" + entity + "\\\"}\",\n"
                    + "  \"pId\": null,\n"
                    + "  \"priority\": \"high\",\n"
                    + "  \"id\": 91989396,\n"
                    + "  \"reqId\": \"11309ef8-d10e-4dec-bcd4-f1fc444d3027\"\n"
                    + "}";

            Response response = given()
                    .log().all()
                    .contentType(ContentType.JSON)
                    .header("Authorization", "Bearer " + jwtToken)
                    .body(body)
                    .when()
                    .post("/enterprise/rest/weguard-v2/fcmUpdate")
                    .then()
                    .log().all()
                    .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Broadcast2 rich text message is successfully sent");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to send Broadcast2 rich text message:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
    }
    //@Test(priority = 4)
    public void SendBroadcastRichTextMessagestoKiosk() {
        test = Extentreportmanager.createTest("SendBroadcastRichTextMessagestoKiosk Test");
        test.assignAuthor("Vamshi");
        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String policyid = properties.getProperty("policyid");
        String reqID = properties.getProperty("reqID");

        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
        
        String entity = sendBroadcastRichTextMessage();

        if (jwtToken != null) {
            String body = "{\r\n"
            		+ "  \"message\": \"{\\\"textColor\\\":\\\"#ffffff\\\",\\\"bgColor\\\":\\\"#000\\\",\\\"textType\\\":\\\"rich\\\",\\\"title\\\":\\\"test100\\\",\\\"body\\\":101,\\\"bMsgBodyRef\\\":\\\""+ entity + "\\\"}\",\r\n"
            		+ "  \"policies\": [\r\n"
            		+ "    {\r\n"
            		+ "      \"WCM\": false,\r\n"
            		+ "      \"policyName\": \"Default Android Kiosk\",\r\n"
            		+ "      \"policyId\": \""+ policyid + "\",\r\n"
            		+ "      \"reqId\": \""+ reqID + "\"\r\n"
            		+ "    }\r\n"
            		+ "  ],\r\n"
            		+ "  \"id\": 10303995,\r\n"
            		+ "  \"reqId\": \""+ reqID +"\"\r\n"
            		+ "}";

            Response response = given()
                    .log().all()
                    .contentType(ContentType.JSON)
                    .header("Authorization", "Bearer " + jwtToken)
                    .body(body)
                    .when()
                    .post("/enterprise/rest/broadcast/policy/multi")
                    .then()
                    .log().all()
                    .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Broadcast2 rich text message is successfully sent");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to send Broadcast2 rich text message:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
    }
    @Test(priority = 5)
    public void SendBroadcastRichTextMessagestoDevice() {
        test = Extentreportmanager.createTest("SendBroadcastRichTextMessagestoDevice Test");
        test.assignAuthor("Vamshi");
        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String topic = properties.getProperty("topic");
        String reqID = properties.getProperty("reqID");
        String pId = properties.getProperty("pId");
        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
        String actCode = loginInfo[1];
        String PactCode = loginInfo[2];
        
        
        String entity = sendBroadcastRichTextMessage();

        if (jwtToken != null) {
        	String body = "{\r\n"
            		+ "  \"topic\": \""+topic+"\",\r\n"
            		+ "  \"type\": \"FCM_MESSAGE\",\r\n"
            		+ "  \"isLicenseLevel\": false,\r\n"
            		+ "  \"actCode\": \""+actCode +"\",\r\n"
            		+ "  \"pActCode\": \""+PactCode +"\",\r\n"
            		+ "  \"message\": \"{\\\"textColor\\\":\\\"#ffffff\\\",\\\"bgColor\\\":\\\"#000000\\\",\\\"textType\\\":\\\"rich\\\",\\\"title\\\":\\\"FORCE\\\",\\\"body\\\":T1,\\\"bMsgBodyRef\\\":\\\""+ entity + "\\\"}\",\r\n"
            		+ "  \"pId\": \"" +pId +"\",\r\n"
            		+ "  \"priority\": \"high\",\r\n"
            		+ "  \"id\": 88276424,\r\n"
            		+ "  \"reqId\": \""+ reqID + "\"\r\n"
            		+ "}";

            Response response = given()
                    .log().all()
                    .contentType(ContentType.JSON)
                    .header("Authorization", "Bearer " + jwtToken)
                    .body(body)
                    .when()
                    .post("/enterprise/rest/weguard-v2/fcmUpdate")
                    .then()
                    .log().all()
                    .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Broadcast2 rich text message is successfully sent");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to send Broadcast2 rich text message:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
    }


}
