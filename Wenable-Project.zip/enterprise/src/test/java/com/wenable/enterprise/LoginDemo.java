// LoginDemo class

package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class LoginDemo {
    private ExtentTest test;

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @Test(priority = 1)
    public void loginToken() {
        test = Extentreportmanager.createTest("Login Test"); // Create a new ExtentTest
        test.assignAuthor("Vamshi");
        String jwtToken = login();
        if (jwtToken != null) {
            test.log(Status.INFO, "Login passed with JWT Token: " + jwtToken);
        }
        Extentreportmanager.flushReport(); // Ensure you flush the report after each test
    }

    public String login() {
        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            // Load properties from the application.properties file
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String email = properties.getProperty("normaluserName");
        test.info("Username is entered");

        String password = properties.getProperty("normalpassword");
        String baseURI = properties.getProperty("BaseURL"); // Rename to 'baseURI' for clarity
        RestAssured.baseURI = baseURI;
        test.info("BaseURL is set to: " + baseURI); // Log BaseURL

        String getlogin = "{\r\n"
                + "  \"userName\": \"" + email + "\",\r\n"
                + "  \"password\": \"" + password + "\"\r\n"
                + "}";

        Response response = given()
                .contentType(ContentType.JSON)
                .body(getlogin)
                .when()
                .post("/enterprise/rest/users/login")
                .then()
                .log().all().extract().response();

        int statusCode = response.getStatusCode();

        if (statusCode == 200) {
            JsonPath jwtToken = new JsonPath(response.asString());
            String JT = jwtToken.getString("entity.jwtToken");
            return JT;
        } else {
            test.log(Status.FAIL, "Login failed with status code: " + statusCode);
            test.log(Status.FAIL, "Invalid Credentials: " + email);
            test.log(Status.FAIL, "Invalid Credentials: " + password);
            return null;
        }
    }
}
