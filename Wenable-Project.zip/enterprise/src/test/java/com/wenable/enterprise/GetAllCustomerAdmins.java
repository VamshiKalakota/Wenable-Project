package com.wenable.enterprise;

import org.testng.annotations.Test;
import io.restassured.path.json.JsonPath;
import io.restassured.http.ContentType;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import static io.restassured.RestAssured.*;

public class GetAllCustomerAdmins extends SuperAdminLogin {
	
	private String[] distributorAndAccountInfo; // Storing the array as a class member
	

	@Test(priority = 1)
	public void getAllCustomeradminsWithZeroDeviceCount() {
		String requestBody = "{\r\n"
        		+ "  \"role\": \"customer_admin\",\r\n"
        		+ "  \"accountsWithZeroDeviceCount\": true,\r\n"
        		+ "  \"distributorIds\": [],\r\n"
        		+ "  \"resellerIds\": [],\r\n"
        		+ "  \"sort\": \"desc\"\r\n"
        		+ "}";

        String IDS=given()
            .contentType(ContentType.JSON)
            .body(requestBody)
            .header("Authorization", "Bearer " + successLogincase())
            
        .when()
            .post("enterprise/rest/users/all/users?page=1&size=100")
        .then()
            .log().all() 
            .assertThat()
            .statusCode(200)
			.extract().response().asString();

		// Extract and store information
		JsonPath ExistingdistID = new JsonPath(IDS);
		String ExistingdistributorID = ExistingdistID.getString("list[2].accountInfo.distributorId");
		String accountID = ExistingdistID.getString("list[2].accountId");
		distributorAndAccountInfo = new String[]{ExistingdistributorID, accountID};
	}

	// Getter method to access distributorAndAccountInfo
	public String[] getDistributorAndAccountInfo() {
		return distributorAndAccountInfo;
	}

	// This method can be called to get the values
	public void extractDistributorAndAccountInfo() {
		getAllCustomeradminsWithZeroDeviceCount();
	}

	@Test(priority = 2)
	public void Associate() {
	    
	    getAllCustomeradminsWithZeroDeviceCount();

	 

	    Properties properties = new Properties();

	    try {
	        FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
	        // Load properties from the application.properties file
	        properties.load(fis);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    String AssociatedistributorId = properties.getProperty("distributorId");
	    String AssociatepartnerId = properties.getProperty("partnerId");

	    String requestbody = "{\r\n"
	        + "  \"distributorId\": \"" + AssociatedistributorId + "\",\r\n"
	        + "  \"partnerId\": \"" + AssociatepartnerId + "\",\r\n"
	        + "  \"transferAccountIds\": [\r\n"
	        + "    \"" + distributorAndAccountInfo[1]  + "\"\r\n" // Use account ID from the previous step
	        + "  ]\r\n"
	        + "}";

	    if (AssociatedistributorId.equals(distributorAndAccountInfo[0])) {
	        throw new RuntimeException("Cannot transfer to the same distributor ID.");
	    }

	    given().log().all()
	        .contentType(ContentType.JSON)
	        .header("Authorization", "Bearer " + successLogincase())
	        .body(requestbody)
	    .when()
	        .post("enterprise/rest/users/transfer/users")
	    .then()
	        .assertThat().statusCode(200)
	        .log().all();
	}
	@Test(priority = 3)
    public void getAllCustomeradminshavingdevices() {
    
        String requestBody2 = "{\r\n"
        		+ "  \"role\": \"customer_admin\",\r\n"
        		+ "  \"accountsWithZeroDeviceCount\": false,\r\n"
        		+ "  \"distributorIds\": [],\r\n"
        		+ "  \"resellerIds\": [],\r\n"
        		+ "  \"sort\": \"desc\"\r\n"
        		+ "}";
              
        given().log().all()
            .contentType(ContentType.JSON)
            .body(requestBody2)
            .header("Authorization", "Bearer " + successLogincase())
            
        .when()
            .post("enterprise/rest/users/all/users?page=1&size=100")
            .then()
            .log().all() 
            .assertThat()
            .statusCode(200);
    }

    }