package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class WeTalk extends NormalUserLogin {
    private ExtentTest test;

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }

    @Test(priority = 1)
    public void getlistofwetalkmessages() {
        test = Extentreportmanager.createTest("getlistofwetalkmessages Test");
        test.assignAuthor("Vamshi");

        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
            String actCode = loginInfo[1];

        if (jwtToken != null) {
            Response response = given()
                    .log().all()
                    .contentType(ContentType.JSON)
                    .header("Authorization", "Bearer " + jwtToken)
                    .when()
                    .get("/enterprise/rest/weguard-v2/license?pageSize=500&page=1")
                    .then()
                    .log().all()
                    .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "WeTalk messages are successfully fetched");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to fetch the WeTalk messages:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
        }
    @Test(priority = 2)
    public void wetalvideocallhistory() {
        test = Extentreportmanager.createTest("wetalvideocallhistory Test");
        test.assignAuthor("Vamshi");

        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
         
            
           
        if (jwtToken != null) {
            Response response = given()
                    .log().all()
                    .contentType(ContentType.JSON)
                    .header("Authorization", "Bearer " + jwtToken)
                    
                    .when()
                    .get("/enterprise/rest/wetalk/history/user/chakrapani.bandhu@weguard.com?page=1&limit=100")
                    .then()
                    .log().all()
                    .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Successfully fetched wetalk video call history");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to fetch wetalk video call history:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
        }
    @Test(priority = 3)
    public void gettodayswetalvideocallhistory() {
        test = Extentreportmanager.createTest("gettodayswetalvideocallhistory Test");
        test.assignAuthor("Vamshi");

        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
         
            
           
        if (jwtToken != null) {
            Response response = given()
                    .log().all()
                    .contentType(ContentType.JSON)
                    .header("Authorization", "Bearer " + jwtToken)
                    
                    .when()
                    .get("/enterprise/rest/wetalk/history/user/chakrapani.bandhu@weguard.com?page=1&limit=100&from=2023-10-20T00:00:00.000Z&to=2023-10-20T23:59:59.999Z")
                    .then()
                    .log().all()
                    .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Successfully fetched today's wetalk video call history");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to fetch today's wetalk video call history:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
        }}

