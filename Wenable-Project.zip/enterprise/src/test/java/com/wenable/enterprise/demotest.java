package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class demotest extends NormalUserLogin {
    private ExtentTest test;
    

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }

    @Test(priority = 1)
    public void getdevices() {
        test = Extentreportmanager.createTest("getdevices Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        RestAssured.baseURI = baseurl;

        String body = "{\r\n"
                + "  \"search\": null,\r\n"
                + "  \"provisioned\": true,\r\n"
                + "  \"replaced\": null,\r\n"
                + "  \"lost\": null,\r\n"
                + "  \"stolen\": null,\r\n"
                + "  \"unEnrolled\": null,\r\n"
                + "  \"active\": null,\r\n"
                + "  \"policyIdList\": null\r\n"
                + "}";

       
        

        int statusCode = given().log().all()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + loginTest())
                .body(body)
                .when()
                .post("/enterprise/rest/v3/device/all?page=1&size=100")
                .then()
                .log().all()
                .assertThat().extract().statusCode();

        if (statusCode == 200) {
            test.log(Status.PASS, "Provisioned devices are retrieved successfully");
        } else {
            test.log(Status.FAIL, "Failed to load devices check failed with status code: " + statusCode);
        }
    }
}
