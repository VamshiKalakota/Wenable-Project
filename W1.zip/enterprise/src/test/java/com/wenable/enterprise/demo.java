package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.path.json.JsonPath;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class demo {
    private ExtentTest test;
    private String jwtToken;
    private String actCode;

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }

    @Test(priority = 1)
    public String[] loginTest() {
        test = Extentreportmanager.createTest("Login Test");
        test.assignAuthor("Vamshi");

        // Call the login method to retrieve JWT Token and ActCode
        return login();
    }

    public String[] login() {
        Properties properties = new Properties();
        FileInputStream fis = null;

        try {
            fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return null; // or throw exception to indicate properties loading failure
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        String email = properties.getProperty("normaluserName");
        String password = properties.getProperty("normalpassword");
        String baseURI = properties.getProperty("BaseURL");
        RestAssured.baseURI = baseURI;

        String getLogin = "{\r\n" + "  \"userName\": \"" + email + "\",\r\n" + "  \"password\": \"" + password + "\"\r\n" + "}";

        Response response = given()
                .contentType(ContentType.JSON)
                .body(getLogin)
                .when()
                .post("/enterprise/rest/users/login")
                .then()
                .log().all()
                .extract().response();

        System.out.println(response.asString());

        int statusCode = response.getStatusCode();

        if (statusCode == 200) {
            JsonPath jwtJson = new JsonPath(response.asString());
            jwtToken = jwtJson.getString("entity.jwtToken");
            actCode = jwtJson.getString("entity.activationCode");
            test.log(Status.PASS, "Login Successfully: JWT Token - " + jwtToken + ", Act Code - " + actCode);
            System.out.println(actCode);
            return new String[]{jwtToken, actCode};
        } else {
            test.log(Status.FAIL, "Login failed with status code: " + statusCode);
            test.log(Status.FAIL, "Invalid Credentials: " + email);
            test.log(Status.FAIL, "Invalid Credentials: " + password);
            return null;
        }
    }
}
