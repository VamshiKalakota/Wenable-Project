package com.wenable.enterprise;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;


import static io.restassured.RestAssured.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class GetAllDevices {
      
	@Test(priority=1)
	
	public void getdevicesinfo() {
		
	
	
	
	
	
	}

}
