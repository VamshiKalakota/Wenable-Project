package com.wenable.enterprise;

public class LoginInfo {
    private final String jwtToken;
    private final String actCode;

    public LoginInfo(String jwtToken, String actCode) {
        this.jwtToken = jwtToken;
        this.actCode = actCode;
    }

    public String getJwtToken() {
        return jwtToken;
    }

    public String getActCode() {
        return actCode;
    }
}
