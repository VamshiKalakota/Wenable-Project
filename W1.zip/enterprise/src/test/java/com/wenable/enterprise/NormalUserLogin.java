package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.path.json.JsonPath;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class NormalUserLogin {
    private ExtentTest test;
    private String jwtToken;
    private String actCode;
    private String PactCode;
    private String AccountID; 

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }

    @Test
    public String[] loginTest() {
        test = Extentreportmanager.createTest("Login Test");
        test.assignAuthor("Vamshi");

        // Call the login method to retrieve JWT Token and ActCode
        String[] loginInfo = login();

        if (loginInfo != null && loginInfo.length == 4) {
            jwtToken = loginInfo[0];
            actCode = loginInfo[1];
            PactCode = loginInfo[2];
            AccountID = loginInfo[3];
            test.log(Status.INFO, "Login passed with JWT Token: " + jwtToken + ", Act Code: " + actCode + ", Pact Code: " + PactCode + ", Account ID: " + AccountID);
        }
        return loginInfo;
    }

    public String[] login() {
        Properties properties = new Properties();
        FileInputStream fis = null;

        try {
            fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return null; // or throw an exception to indicate properties loading failure
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        String email = properties.getProperty("normaluserName");
        String password = properties.getProperty("normalpassword");
        String baseURI = properties.getProperty("BaseURL");
        RestAssured.baseURI=(baseURI); 

        String getLogin = "{\r\n" + "  \"userName\": \"" + email + "\",\r\n" + "  \"password\": \"" + password + "\"\r\n" + "}";

        Response response = given()
                .contentType(ContentType.JSON)
                .body(getLogin)
                .when()
                .post("/enterprise/rest/users/login")
                .then()
                .log().all()
                .extract().response();

        int statusCode = response.getStatusCode();

        if (statusCode == 200) {
            JsonPath jwtJson = new JsonPath(response.asString());
            jwtToken = jwtJson.getString("entity.jwtToken");
            actCode = jwtJson.getString("entity.activationCode");
            PactCode = jwtJson.getString("entity.productActivationCode");
            AccountID = jwtJson.getString("entity.userData.accountId");

            test.log(Status.PASS, "Login Successfully: JWT Token - " + jwtToken + ", Act Code - " + actCode + ", Pact Code - " + PactCode+", AccID - " + AccountID);
            return new String[]{jwtToken, actCode, PactCode, AccountID};
        } else {
            test.log(Status.FAIL, "Login failed with status code: " + statusCode);
            test.log(Status.FAIL, "Invalid Credentials: " + email);
            test.log(Status.FAIL, "Invalid Credentials: " + password);
            return null;
        }
    }
}
