package com.wenable.enterprise;

import org.testng.annotations.Test;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;


import static io.restassured.RestAssured.*;

public class Privacypolicyterms extends SuperAdminLogin {

    @Test(priority = 1)
    public void privacypolicyterms() {
    

        given()
            .contentType(ContentType.JSON)
            .header("Authorization", "Bearer " + successLogincase())
            
        .when()
            .get("enterprise/rest/privacypolicy/0")
        .then()
            .log().all() 
            .assertThat()
            .statusCode(200);
    }}