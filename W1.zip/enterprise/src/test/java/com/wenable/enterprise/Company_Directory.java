package com.wenable.enterprise;

import static io.restassured.RestAssured.given;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Company_Directory extends NormalUserLogin {
	 private ExtentTest test;

	    @BeforeSuite
	    public void setUp() {
	        Extentreportmanager.initialize();
	    }

	    @AfterSuite
	    public void tearDown() {
	        Extentreportmanager.flushReport();
	    }

	   // @Test(priority = 1)
	public void GetListofContacts() {
        test = Extentreportmanager.createTest("GetListofContacts Test");
        test.assignAuthor("Vamshi");

        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];
            String AccountID = loginInfo[3];
            String body="{\r\n"
            		+ "  \"accountId\": \""+ AccountID + "\",\r\n"
            		+ "  \"searchText\": null\r\n"
            		+ "}";

        if (jwtToken != null) {
            Response response = given()
                    .log().all()
                    .contentType(ContentType.JSON)
                    .header("Authorization", "Bearer " + jwtToken)
                    .body(body)
                    .when()
                    .post("/enterprise/rest/contacts/all?page=1&size=100")
                    .then()
                    .log().all()
                    .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "List of Contacts are successfully fetched");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to fetch the List of Contacts:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
    }
	    @Test(priority = 2)
	    public void CreateContact() {
	        Base baseObject = new Base(); // Create an instance of the Base class

	        test = Extentreportmanager.createTest("CreateContact Test");
	        test.assignAuthor("Vamshi");

	        String[] loginInfo = loginTest();
	        String jwtToken = loginInfo[0];
	        String AccountID = loginInfo[3];
	        String body = baseObject.getCreateContactRequestBody(AccountID); // Get the request body

	        if (jwtToken != null) {
	            Response response = given()
	                    .log().all()
	                    .contentType(ContentType.JSON)
	                    .header("Authorization", "Bearer " + jwtToken)
	                    .body(body)
	                    .when()
	                    .post("/enterprise/rest/contacts/save")
	                    .then()
	                    .log().all()
	                    .extract().response();

	            int statusCode = response.getStatusCode();

	            if (statusCode == 200) {
	                test.log(Status.PASS, "Contact is successfully created");
	                // Log the response data
	                test.log(Status.INFO, "Response Data: " + response.asString());
	            } else {
	                test.log(Status.FAIL, "Failed to create a Contact: " + statusCode);
	                // Log the response data
	                test.log(Status.INFO, "Response Data: " + response.asString());
	            }
	        }
	    }

}
