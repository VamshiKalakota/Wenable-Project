package com.wenable.enterprise;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class WeBox extends NormalUserLogin {
    private ExtentTest test;

    @BeforeSuite
    public void setUp() {
        Extentreportmanager.initialize();
    }

    @AfterSuite
    public void tearDown() {
        Extentreportmanager.flushReport();
    }

    @Test(priority = 1)
    public List<String> getPolicyInfo() {
        test = Extentreportmanager.createTest("Get policy info Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        RestAssured.baseURI = baseurl;

        // Call the login method from NormalUserLogin to get JWT token and ActCode
        String[] loginInfo = loginTest();
        String jwtToken = loginInfo[0];

        Response response = given()
                .log().all()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + jwtToken)
                .when()
                .get("/enterprise/rest/v3/policy/all?page=1&size=100&deviceCount=true&impersonator=false")
                .then()
                .log().all()
                .extract().response();

        int statusCode = response.getStatusCode();

        if (statusCode == 200 ) {
            test.log(Status.PASS, "Retrieved all the policies successfully");
            String responseBody = response.asString();

            JsonPath jsonPath = new JsonPath(responseBody);

            List<String> policyIds = jsonPath.getList("list.id");

            test.log(Status.INFO, "Policy IDs: " + policyIds);

            return policyIds;
        } else {
            test.log(Status.FAIL, "Failed to fetch all policies with status code: " + statusCode);
            return Collections.emptyList(); // Return an empty list in case of failure
        }
    }

    
   //@Test(priority = 2)
    public void weboxupload() {
        test = Extentreportmanager.createTest("weboxupload Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        String FILEPATH =properties.getProperty("Filepath");
        String PolicyID =properties.getProperty("policyid");
        RestAssured.baseURI = baseurl;
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];

        String body = "{\r\n"
        		+ "  \"policyIds\": [\r\n"
        		+ "    \""+PolicyID+"\"\r\n"
        		+ "  ],\r\n"
        		+ "  \"file\": {\r\n"
        		+ "    \"fName\": \"1\",\r\n"
        		+ "    \"fSize\": 30311,\r\n"
        		+ "    \"fPath\": \""+ FILEPATH + "\",\r\n"
        		+ "    \"fCheckSum\": \"ebaeb61cfc3f219f43a3a884d6a2dcb0\",\r\n"
        		+ "    \"fExtension\": \".PNG\",\r\n"
        		+ "    \"timestamp\": 1697432559310\r\n"
        		+ "  }\r\n"
        		+ "}";


        Response response  = given().log().all()
        	    .contentType(ContentType.JSON)
        	    .header("Authorization", "Bearer " + jwtToken)
        	    .body(body)
        	    .when()
        	    .post("/enterprise/rest/weguard-v2/webox/files/upload")
        	    .then()
                .assertThat().statusCode(200)
                .log().all()
                .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Default Android Kiosk policy details are successfully fetched");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to fetch the Default Android Kiosk policy details:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
    
   @Test(priority = 3)
    public void uploadFileToAllPolicies() {
        test = Extentreportmanager.createTest("uploadFileToAllPolicies Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        String FILEPATH1 = properties.getProperty("Fileuploadtobulkpolicies");
        RestAssured.baseURI = baseurl;
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];

        // Retrieve the list of policy IDs
        List<String> policyIds = getPolicyInfo();

        // Create the request body with the list of policy IDs
        StringBuilder policyIdsJson = new StringBuilder();
        policyIdsJson.append("[");
        for (String policyId : policyIds) {
            policyIdsJson.append("\"").append(policyId).append("\",");
        }
        policyIdsJson.deleteCharAt(policyIdsJson.length() - 1); // Remove the last comma
        policyIdsJson.append("]");

        // Create the complete request body
        String body = "{\n"
                + "  \"policyIds\": " + policyIdsJson.toString() + ",\n"
                + "  \"file\": {\n"
                + "    \"fName\": \"Lower Set BSLS\",\n"
                + "    \"fSize\": 378157929,\n" // Add the file size here
                + "    \"fPath\": \"" + FILEPATH1 + "\",\n"
                + "    \"fCheckSum\": \"de667bef020112f9e9ed5d50d96fcb47\",\n"
                + "    \"fExtension\": \".pdf\",\n"
                + "    \"timestamp\": 1697780012866\n"
                + "  }\n"
                + "}";

        Response response = given().log().all()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + jwtToken)
                .body(body)
                .when()
                .post("/enterprise/rest/weguard-v2/webox/files/upload")
                .then()
                .log().all()
                .extract().response();
        int statusCode = response.getStatusCode();

        if (statusCode == 200) {
            test.log(Status.PASS, "WeBox file is uploaded to all policies successfully");
            // Log the response data
            test.log(Status.INFO, "Response Data: " + response.asString());
        } else {
            test.log(Status.FAIL, "Failed to upload WeBox files to all policies: " + statusCode);
            // Log the response data
            test.log(Status.INFO, "Response Data: " + response.asString());
        }
    }
   //@Test(priority = 4)
    public void getlistofsharedfolers() {
        test = Extentreportmanager.createTest("getlistofsharedfolders Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        
        RestAssured.baseURI = baseurl;
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];
        
        Response response  = given().log().all()
        	    .contentType(ContentType.JSON)
        	    .header("Authorization", "Bearer " + jwtToken)	    
        	    .when()
        	    .get("/enterprise/rest/weguard-v2/webox/upload/folder/9LX20/shared?page=1&limit=30")
        	    .then()
                .assertThat().statusCode(200)
                .log().all()
                .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Successfully fetced listofshared folders");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to fetch the listofshared folders:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }

    
    //@Test(priority = 5)
    public void weboxsharedflodercreate() {
        test = Extentreportmanager.createTest("weboxsharedflodercreate Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        
        RestAssured.baseURI = baseurl;
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];
            String actcode = loginInfo[1];
        String body = "{\r\n"
        		+ "  \"name\": \"vamshisharedfloder\",\r\n"
        		+ "  \"policies\": [],\r\n"
        		+ "  \"shared\": true,\r\n"
        		+ "  \"actCode\": \""+actcode+"\"\r\n"
        		+ "}";


        Response response  = given().log().all()
        	    .contentType(ContentType.JSON)
        	    .header("Authorization", "Bearer " + jwtToken)
        	    .body(body)
        	    .when()
        	    .post("/enterprise/rest/weguard-v2/webox/upload/folder/create")
        	    .then()
                .assertThat().statusCode(200)
                .log().all()
                .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "WeBox Shared floder is successfully created");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to create WeBox Shared floder :" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
   // @Test(priority = 6)
    public void getlistofgroupfolders() {
        test = Extentreportmanager.createTest("getlistofgroupfolders Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        
        RestAssured.baseURI = baseurl;
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];
        
        Response response  = given().log().all()
        	    .contentType(ContentType.JSON)
        	    .header("Authorization", "Bearer " + jwtToken)	    
        	    .when()
        	    .get("/enterprise/rest/weguard-v2/webox/upload/folder/9LX20/group?page=1&limit=100000")
        	    .then()
                .assertThat().statusCode(200)
                .log().all()
                .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Successfully fetced listofgroup folders");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to fetch the listofgroup folders:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
   //@Test(priority = 7)
    public void creategroupfolder() {
        test = Extentreportmanager.createTest("creategroupfolder Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        String PolicyID =properties.getProperty("policyid");
        
        RestAssured.baseURI = baseurl;
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];
            String actcode = loginInfo[1];
            String body ="{\r\n"
            		+ "  \"name\": \"APIGroup\",\r\n"
            		+ "  \"policies\": [\r\n"
            		+ "    {\r\n"
            		+ "      \"policyId\": \""+PolicyID+"\",\r\n"
            		+ "      \"policyName\": \"Adithya 5.1.21-rc1(QA)\",\r\n"
            		+ "      \"policyType\": \"ANDROID_KIOSK\"\r\n"
            		+ "    }\r\n"
            		+ "  ],\r\n"
            		+ "  \"shared\": false,\r\n"
            		+ "  \"actCode\": \""+actcode+"\"\r\n"
            		+ "}";
        
        Response response  = given().log().all()
        	    .contentType(ContentType.JSON)
        	    .header("Authorization", "Bearer " + jwtToken)	 
        	    .body(body)
        	    .when()
        	    .post("/enterprise/rest/weguard-v2/webox/upload/folder/create")
        	    .then()
                .assertThat().statusCode(200)
                .log().all()
                .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Successfully created group folder");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to create group folders:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
    //@Test(priority = 8)
    public void sharedfolderconfigupdate() {
        test = Extentreportmanager.createTest("sharedfolderconfigupdate Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        
        RestAssured.baseURI = baseurl;
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];
            String actcode = loginInfo[1];
            String body ="{\r\n"
            		+ "  \"s3Config\": {\r\n"
            		+ "    \"enabled\": true,\r\n"
            		+ "    \"identityPoolId\": \"us-west-2:9e8b7389-6218-4d4c-bca4-1768f3791613\",\r\n"
            		+ "    \"region\": \"us-west-2\",\r\n"
            		+ "    \"bucketName\": [\r\n"
            		+ "      \"laf-dev\"\r\n"
            		+ "    ]\r\n"
            		+ "  },\r\n"
            		+ "  \"signEnabled\": false,\r\n"
            		+ "  \"uploadSizeLimit\": \"10000000\",\r\n"
            		+ "  \"type\": \"Shared\",\r\n"
            		+ "  \"activationCode\": \""+actcode+"\"\r\n"
            		+ "}";
        
        Response response  = given().log().all()
        	    .contentType(ContentType.JSON)
        	    .header("Authorization", "Bearer " + jwtToken)	 
        	    .body(body)
        	    .when()
        	    .post("/enterprise/rest/weguard-v2/webox/upload/config")
        	    .then()
                .assertThat().statusCode(200)
                .log().all()
                .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Successfully updated shared folder config");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to updated shared folder config:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
   // @Test(priority = 9)
    public void groupfolderconfigupdate() {
        test = Extentreportmanager.createTest("groupfolderconfigupdate Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        
        RestAssured.baseURI = baseurl;
        String PolicyID =properties.getProperty("policyid");
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];
           
            String body ="{\r\n"
            		+ "  \"s3Config\": null,\r\n"
            		+ "  \"signEnabled\": false,\r\n"
            		+ "  \"uploadSizeLimit\": \"5000000\",\r\n"
            		+ "  \"type\": \"Policy\",\r\n"
            		+ "  \"policyId\": \""+PolicyID+"\"\r\n"
            		+ "}";
        
        Response response  = given().log().all()
        	    .contentType(ContentType.JSON)
        	    .header("Authorization", "Bearer " + jwtToken)	 
        	    .body(body)
        	    .when()
        	    .post("/enterprise/rest/weguard-v2/webox/upload/config")
        	    .then()
                .assertThat().statusCode(200)
                .log().all()
                .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Successfully updated group folder config");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to updated group folder config:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
    
    @Test(priority=10)
    public void getlistoffilesfromsinglepolicy() {
        test = Extentreportmanager.createTest("getlistoffilesfromsinglepolicy Test");
        test.assignAuthor("Vamshi");

        Properties properties = new Properties();

        try {
            FileInputStream fis = new FileInputStream("src/test/java/com/wenable/enterprise/application.properties");
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String baseurl = properties.getProperty("BaseURL");
        
        RestAssured.baseURI = baseurl;
       
     // Call the loginTest method to get JWT token and ActCode
        String[] loginInfo = loginTest();
            String jwtToken = loginInfo[0];
          
        Response response  = given().log().all()
        	    .contentType(ContentType.JSON)
        	    .header("Authorization", "Bearer " + jwtToken)	 
        	    .when()
        	    .get("/enterprise/rest/weguard-v2/webox/config/6526910774b6c86f4b98741a")
        	    .then()
                .assertThat().statusCode(200)
                .log().all()
                .extract().response();

            int statuscode = response.getStatusCode();

            if (statuscode == 200) {
                test.log(Status.PASS, "Successfully fetched list of files in Android policy");
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            } else {
                test.log(Status.FAIL, "Failed to fetch list of files in Android policy:" + statuscode);
                // Log the response data
                test.log(Status.INFO, "Response Data: " + response.asString());
            }
        }
    
}
